<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script>
 window.ENV = {"PUBLIC_PREVIEW_DOMAIN":"csb.app","PUBLIC_ENVIRONMENT":"production","PUBLIC_API_DOMAIN":"https://codesandbox.io","PUBLIC_PITCHER_DOMAIN":"preview.csb.app","PUBLIC_PITCHER_MANAGER_URL":"https://codesandbox.io","PUBLIC_UI_URL":"https://codesandbox.io","PUBLIC_V1_URL":"https://codesandbox.io","PUBLIC_BASE_PATH":"/p","PUBLIC_AMPLITUDE_API_KEY":"a205ed9b06a7baf5a594bdd30293aa80","PUBLIC_VERSION":"0.0.371","PUBLIC_SENTRY_DSN":"https://86af9ec4f27f4c06b452949ad7912a0c@o72233.ingest.sentry.io/5900707"}
</script>
<style>
    body {
      background: var(--preferred-bg-color);  overscroll-behavior-x: none; margin: 0; padding: 0;}
    html { overscroll-behavior-x: none;  margin: 0; padding: 0; }

</style>

<link href="//sandpack-cdn-v2.codesandbox.io" rel="preconnect" />

<link
  href="https://codesandbox.io/p/fonts/inter/inter.css"
  rel="stylesheet"
/>
  <script>
  try {
    let bgColor = "#0D0D0D"
    let color = "#E6E6E6"

    const preferredTheme = window.localStorage.getItem("CSB/THEME/0.1")

    if (preferredTheme) {
      if (preferredTheme) {
        const data = JSON.parse(preferredTheme)

        // Old theme
        if (data.type && data.colors) {
          bgColor = data.colors["neutral-bg-base"]
          color = data.type === "light" ? "#1A1A1A" : "#E6E6E6"
        }

      }
    }
    document.documentElement.style.setProperty(
      "--preferred-bg-color",
      bgColor
    );
    document.documentElement.style.setProperty(
      "--preferred-color",
      color
    );
  } catch (error) {
    console.log("Could not set preferred theme", error)
    // no op
  }
  </script>

<style>
    @keyframes ssr-loading-color {
        0% {
            stroke: #9D8BF9;
        }
        24% {
            stroke: #9D8BF9;
        }
        25% {
            stroke: #9D8BF9;
        }
        49% {
            stroke: #9D8BF9;
        }
        50% {
            stroke: #F68484;
        }
        74% {
            stroke: #F68484;
        }
        75% {
            stroke: #F68484;
        }
        99% {
            stroke: #F68484;
        }
    }

    @keyframes ssr-loading-spacing {
        0% {
            stroke-DashArray: 0 200;
        }
        45% {
            stroke-DashOffset: 0;
            stroke-DashArray: 200 200;
        }
        90% {
            stroke-DashOffset: -200;
            stroke-DashArray: 200 200;
        }
        100% {
            stroke-DashOffset: -200;
            stroke-DashArray: 200 200;
        }
    }
</style>

    <script type="module" crossorigin src="/p/assets/index-5ebc5b81.js"></script>
    <link rel="modulepreload" crossorigin href="/p/assets/vendor-9e62fa76.js">
    <link rel="stylesheet" href="/p/assets/index-1b3a74fc.css">
  </head>
  <body>
    <div id="root"><div id="ssr-loading" style="display:flex;align-items:center;justify-content:center;height:100vh;flex-direction:column"><svg style="width:44px;height:44px" viewBox="0 0 100 100"><polyline fill="none" points="0, 0, 100, 0, 100, 100" stroke-width="15" style="stroke:gray"></polyline><polyline fill="none" points="0, 0, 0, 100, 100, 100" stroke-width="15" style="stroke:gray"></polyline><polyline fill="none" points="0, 0, 100, 0, 100, 100" stroke-width="15" style="animation:ssr-loading-spacing 1.2s ease-in, ssr-loading-color 4.8s linear;animation-iteration-count:infinite;animation-direction:normal;animation-fill-mode:forwards;transform-origin:center center"></polyline><polyline fill="none" points="0, 0, 0, 100, 100, 100" stroke-width="15" style="animation:ssr-loading-spacing 1.2s ease-in, ssr-loading-color 4.8s linear;animation-iteration-count:infinite;animation-direction:normal;animation-fill-mode:forwards;transform-origin:center center"></polyline></svg><div id="ssr-loading-text" style="text-align:center;max-width:65ch;color:var(--preferred-color);font-family:Inter, -apple-system, &quot;system-ui&quot;, &quot;Segoe UI&quot;, Roboto, Oxygen-Sans, Ubuntu;min-width:300px;padding-left:8px;padding-right:8px;padding-top:24px;font-size:13px;-webkit-font-smoothing:antialiased"> </div><script> if ("serviceWorker" in navigator) {
    navigator.serviceWorker.getRegistrations().then(registrations => {
      const match = registrations.find((registration)  => {
        return registration.active && registration.active.scriptURL.includes("editor-sw.js")
      })

      const loadingEl = document.querySelector('#ssr-loading-text')

      if (loadingEl) {
        loadingEl.textContent = match ? 'Loading editor...' : 'Installing editor...';
      }
    }).catch(() => {})
  }</script></div></div>
    
  <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"8d804553089dd1e7","version":"2024.10.3","serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"7449176f14aa420c959831edd48bd5b7","b":1}' crossorigin="anonymous"></script>
</body>
</html>
