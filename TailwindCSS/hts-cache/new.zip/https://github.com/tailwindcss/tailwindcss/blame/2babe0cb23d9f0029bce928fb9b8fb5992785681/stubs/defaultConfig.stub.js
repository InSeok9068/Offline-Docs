





<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://github.githubassets.com">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <link crossorigin="anonymous" media="all" integrity="sha512-ZUjVod2EvYMDbGqRSyW0rpfgBq3i+gnR/4PfrzLsy5f20oIcRfgFQFVKgi3Ztp917bP1K/kdP5q8+nAlJ3+cFA==" rel="stylesheet" href="https://github.githubassets.com/assets/frameworks-6548d5a1dd84bd83036c6a914b25b4ae.css" />
  <link crossorigin="anonymous" media="all" integrity="sha512-HNV7VuXI98SSFimaE7r8eVsgrmzC37AMNXw1GrNbOl4wN3ATov+SdHusRTAAf4NPoRsUcOOQyYsOCA0AcN4m0w==" rel="stylesheet" href="https://github.githubassets.com/assets/site-1cd57b56e5c8f7c49216299a13bafc79.css" />
    <link crossorigin="anonymous" media="all" integrity="sha512-aX4OkLpzulpadvOncEEPpJZnQyeKNm2npzJowbL5JxptkoZXNPPy61R059xmEa3YyVF4Y4YXB6g+5o08uvdWpA==" rel="stylesheet" href="https://github.githubassets.com/assets/github-697e0e90ba73ba5a5a76f3a770410fa4.css" />
    
    
    
    


  <meta name="viewport" content="width=device-width">
  
  <title>tailwindcss/stubs/defaultConfig.stub.js at 2babe0cb23d9f0029bce928fb9b8fb5992785681 · tailwindcss/tailwindcss · GitHub</title>
    <meta name="description" content="A utility-first CSS framework for rapid UI development. - tailwindcss/tailwindcss">
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">

    <meta name="twitter:image:src" content="https://repository-images.githubusercontent.com/106017343/67c23f00-9462-11e9-9dba-c3970f6c612b" /><meta name="twitter:site" content="@github" /><meta name="twitter:card" content="summary_large_image" /><meta name="twitter:title" content="tailwindcss/tailwindcss" /><meta name="twitter:description" content="A utility-first CSS framework for rapid UI development. - tailwindcss/tailwindcss" />
    <meta property="og:image" content="https://repository-images.githubusercontent.com/106017343/67c23f00-9462-11e9-9dba-c3970f6c612b" /><meta property="og:site_name" content="GitHub" /><meta property="og:type" content="object" /><meta property="og:title" content="tailwindcss/tailwindcss" /><meta property="og:url" content="https://github.com/tailwindcss/tailwindcss" /><meta property="og:description" content="A utility-first CSS framework for rapid UI development. - tailwindcss/tailwindcss" />

  <link rel="assets" href="https://github.githubassets.com/">
  
  

  <meta name="request-id" content="9EEA:06F3:24E3:33FE:5E53B65A" data-pjax-transient="true"/><meta name="html-safe-nonce" content="bf3511025571ac5a2676e45dbdba7a105de6202e" data-pjax-transient="true"/><meta name="visitor-payload" content="eyJyZWZlcnJlciI6Imh0dHA6Ly9naXRodWIuY29tL3RhaWx3aW5kY3NzL3RhaWx3aW5kY3NzL2JsYW1lL21hc3Rlci9zdHVicy9kZWZhdWx0Q29uZmlnLnN0dWIuanMiLCJyZXF1ZXN0X2lkIjoiOUVFQTowNkYzOjI0RTM6MzNGRTo1RTUzQjY1QSIsInZpc2l0b3JfaWQiOiI4NDA1MzM0Mjk2NDUwMjgyOTQ2IiwicmVnaW9uX2VkZ2UiOiJzYS1lYXN0LTEiLCJyZWdpb25fcmVuZGVyIjoic2EtZWFzdC0xIn0=" data-pjax-transient="true"/><meta name="visitor-hmac" content="0034886c12c6d3bf9d8f38e41ed581c1d835cec4152f9143baaa98510021c784" data-pjax-transient="true"/>



  <meta name="github-keyboard-shortcuts" content="repository" data-pjax-transient="true" />

  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

      <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
    <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
    <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">

  <meta name="octolytics-host" content="collector.githubapp.com" /><meta name="octolytics-app-id" content="github" /><meta name="octolytics-event-url" content="https://collector.githubapp.com/github-external/browser_event" /><meta name="octolytics-dimension-ga_id" content="" class="js-octo-ga-id" />
<meta name="analytics-location" content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/blame" data-pjax-transient="true" />



    <meta name="google-analytics" content="UA-3769691-2">


<meta class="js-ga-set" name="dimension1" content="Logged Out">



  

      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

      <meta name="expected-hostname" content="github.com">


    <meta name="enabled-features" content="MARKETPLACE_FEATURED_BLOG_POSTS,MARKETPLACE_INVOICED_BILLING,MARKETPLACE_SOCIAL_PROOF_CUSTOMERS,MARKETPLACE_TRENDING_SOCIAL_PROOF,MARKETPLACE_RECOMMENDATIONS,MARKETPLACE_PENDING_INSTALLATIONS,RELATED_ISSUES">

  <meta http-equiv="x-pjax-version" content="29999ca8cf0c8ddf469b9759ce08131a">
  

      <link href="https://github.com/tailwindcss/tailwindcss/commits/2babe0cb23d9f0029bce928fb9b8fb5992785681.atom" rel="alternate" title="Recent Commits to tailwindcss:2babe0cb23d9f0029bce928fb9b8fb5992785681" type="application/atom+xml">
      <meta name="robots" content="noindex, nofollow" />

  <meta name="go-import" content="github.com/tailwindcss/tailwindcss git https://github.com/tailwindcss/tailwindcss.git">

  <meta name="octolytics-dimension-user_id" content="30317862" /><meta name="octolytics-dimension-user_login" content="tailwindcss" /><meta name="octolytics-dimension-repository_id" content="106017343" /><meta name="octolytics-dimension-repository_nwo" content="tailwindcss/tailwindcss" /><meta name="octolytics-dimension-repository_public" content="true" /><meta name="octolytics-dimension-repository_is_fork" content="false" /><meta name="octolytics-dimension-repository_network_root_id" content="106017343" /><meta name="octolytics-dimension-repository_network_root_nwo" content="tailwindcss/tailwindcss" /><meta name="octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" content="false" />




  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://github.githubassets.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" class="js-site-favicon" href="https://github.githubassets.com/favicon.ico">

<meta name="theme-color" content="#1e2327">


  <link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-out env-production min-width-lg full-width">
    

  <div class="position-relative js-header-wrapper ">
    <a href="#start-of-content" tabindex="1" class="px-2 py-4 bg-blue text-white show-on-focus js-skip-to-content">Skip to content</a>
    <span class="Progress progress-pjax-loader position-fixed width-full js-pjax-loader-bar">
      <span class="progress-pjax-loader-bar top-0 left-0" style="width: 0%;"></span>
    </span>

    
    



        <header class="Header-old header-logged-out  position-relative f4 py-2" role="banner">
  <div class="container-lg d-flex px-3">
    <div class="d-flex flex-justify-between flex-items-center">
        <a class="mr-4" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
          <svg height="32" class="octicon octicon-mark-github text-white" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg>
        </a>
    </div>

    <div class="HeaderMenu HeaderMenu--logged-out d-flex flex-justify-between flex-items-center flex-auto">
      <div class="d-none">
        <button class="btn-link js-details-target" type="button" aria-label="Toggle navigation" aria-expanded="false">
          <svg height="24" class="octicon octicon-x text-gray" viewBox="0 0 12 16" version="1.1" width="18" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
        </button>
      </div>

        <nav class="mt-0" aria-label="Global">
          <ul class="d-flex list-style-none">
              <li class=" mr-3 mr-lg-3 edge-item-fix position-relative flex-wrap flex-justify-between d-flex flex-items-center ">
                <details class="HeaderMenu-details details-overlay details-reset width-full">
                  <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap  d-inline-block">
                    Why GitHub?
                    <svg x="0px" y="0px" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-relative">
                      <path d="M1,1l6.2,6L13,1"></path>
                    </svg>
                  </summary>
                  <div class="dropdown-menu flex-auto rounded-1 bg-white px-0 mt-0  p-4 left-n4 position-absolute">
                    <a href="/features" class="py-2 lh-condensed-ultra d-block link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Features">Features <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a>
                    <ul class="list-style-none f5 pb-3">
                      <li class="edge-item-fix"><a href="/features/code-review/" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Code review">Code review</a></li>
                      <li class="edge-item-fix"><a href="/features/project-management/" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Project management">Project management</a></li>
                      <li class="edge-item-fix"><a href="/features/integrations" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Integrations">Integrations</a></li>
                      <li class="edge-item-fix"><a href="/features/actions" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Actions">Actions</a></li>
                          <li class="edge-item-fix"><a href="/features/packages" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to GitHub Packages">Packages</a></li>
                      <li class="edge-item-fix"><a href="/features/security" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Security">Security</a></li>
                      <li class="edge-item-fix"><a href="/features#team-management" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Team management">Team management</a></li>
                      <li class="edge-item-fix"><a href="/features#hosting" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Code hosting">Hosting</a></li>
                    </ul>

                    <ul class="list-style-none mb-0 border-lg-top pt-lg-3">
                      <li class="edge-item-fix"><a href="/customer-stories" class="py-2 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Customer stories">Customer stories <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                      <li class="edge-item-fix"><a href="/security" class="py-2 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Security">Security <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                    </ul>
                  </div>
                </details>
              </li>
              <li class=" mr-3 mr-lg-3">
                <a href="/enterprise" class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-ga-click="(Logged out) Header, go to Enterprise">Enterprise</a>
              </li>

              <li class=" mr-3 mr-lg-3 edge-item-fix position-relative flex-wrap flex-justify-between d-flex flex-items-center ">
                <details class="HeaderMenu-details details-overlay details-reset width-full">
                  <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap  d-inline-block">
                    Explore
                    <svg x="0px" y="0px" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-relative">
                      <path d="M1,1l6.2,6L13,1"></path>
                    </svg>
                  </summary>

                  <div class="dropdown-menu flex-auto rounded-1 bg-white px-0 pt-2 pb-0 mt-0  p-4 left-n4 position-absolute">
                    <ul class="list-style-none mb-3">
                      <li class="edge-item-fix"><a href="/explore" class="py-2 lh-condensed-ultra d-block link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Explore">Explore GitHub <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                    </ul>

                    <h4 class="text-gray-light text-normal text-mono f5 mb-2  border-top pt-3">Learn &amp; contribute</h4>
                    <ul class="list-style-none mb-3">
                      <li class="edge-item-fix"><a href="/topics" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Topics">Topics</a></li>
                        <li class="edge-item-fix"><a href="/collections" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Collections">Collections</a></li>
                      <li class="edge-item-fix"><a href="/trending" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Trending">Trending</a></li>
                      <li class="edge-item-fix"><a href="https://lab.github.com/" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Learning lab">Learning Lab</a></li>
                      <li class="edge-item-fix"><a href="https://opensource.guide" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Open source guides">Open source guides</a></li>
                    </ul>

                    <h4 class="text-gray-light text-normal text-mono f5 mb-2  border-top pt-3">Connect with others</h4>
                    <ul class="list-style-none mb-0">
                      <li class="edge-item-fix"><a href="https://github.com/events" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Events">Events</a></li>
                      <li class="edge-item-fix"><a href="https://github.community" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Community forum">Community forum</a></li>
                      <li class="edge-item-fix"><a href="https://education.github.com" class="py-2 pb-0 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to GitHub Education">GitHub Education</a></li>
                    </ul>
                  </div>
                </details>
              </li>

              <li class=" mr-3 mr-lg-3">
                <a href="/marketplace" class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-ga-click="(Logged out) Header, go to Marketplace">Marketplace</a>
              </li>

              <li class=" mr-3 mr-lg-3 edge-item-fix position-relative flex-wrap flex-justify-between d-flex flex-items-center ">
                <details class="HeaderMenu-details details-overlay details-reset width-full">
                  <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap  d-inline-block">
                    Pricing
                    <svg x="0px" y="0px" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-relative">
                       <path d="M1,1l6.2,6L13,1"></path>
                    </svg>
                  </summary>

                  <div class="dropdown-menu flex-auto rounded-1 bg-white px-0 pt-2 pb-4 mt-0  p-4 left-n4 position-absolute">
                    <a href="/pricing" class="pb-2 lh-condensed-ultra d-block link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Pricing">Plans <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a>

                    <ul class="list-style-none mb-3">
                      <li class="edge-item-fix"><a href="/pricing#feature-comparison" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Compare plans">Compare plans</a></li>
                      <li class="edge-item-fix"><a href="https://enterprise.github.com/contact" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Contact Sales">Contact Sales</a></li>
                    </ul>

                    <ul class="list-style-none mb-0  border-top pt-3">
                      <li class="edge-item-fix"><a href="/nonprofit" class="py-2 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Nonprofits">Nonprofit <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                      <li class="edge-item-fix"><a href="https://education.github.com" class="py-2 pb-0 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover"  data-ga-click="(Logged out) Header, go to Education">Education <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                    </ul>
                  </div>
                </details>
              </li>
          </ul>
        </nav>

      <div class="d-flex flex-items-center px-0 text-center text-left">
          <div class="d-lg-flex ">
            <div class="header-search mr-3 scoped-search site-scoped-search js-site-search position-relative js-jump-to"
  role="combobox"
  aria-owns="jump-to-results"
  aria-label="Search or jump to"
  aria-haspopup="listbox"
  aria-expanded="false"
>
  <div class="position-relative">
    <!-- '"` --><!-- </textarea></xmp> --></option></form><form class="js-site-search-form" role="search" aria-label="Site" data-scope-type="Repository" data-scope-id="106017343" data-scoped-search-url="/tailwindcss/tailwindcss/search" data-unscoped-search-url="/search" action="/tailwindcss/tailwindcss/search" accept-charset="UTF-8" method="get"><input name="utf8" type="hidden" value="&#x2713;" />
      <label class="form-control input-sm header-search-wrapper p-0 header-search-wrapper-jump-to position-relative d-flex flex-justify-between flex-items-center js-chromeless-input-container">
        <input type="text"
          class="form-control input-sm header-search-input jump-to-field js-jump-to-field js-site-search-focus js-site-search-field is-clearable"
          data-hotkey="s,/"
          name="q"
          value=""
          placeholder="Search"
          data-unscoped-placeholder="Search GitHub"
          data-scoped-placeholder="Search"
          autocapitalize="off"
          aria-autocomplete="list"
          aria-controls="jump-to-results"
          aria-label="Search"
          data-jump-to-suggestions-path="/_graphql/GetSuggestedNavigationDestinations"
          spellcheck="false"
          autocomplete="off"
          >
          <input type="hidden" data-csrf="true" class="js-data-jump-to-suggestions-path-csrf" value="3ay2iR6wuPaugXE6KhrmbU7e147HbsS7n1+n0F2K9D67fosGOF6zngS95f9a6o7EmNGyynqj2c3zP1MHrUL3Ow==" />
          <input type="hidden" class="js-site-search-type-field" name="type" >
            <img src="https://github.githubassets.com/images/search-key-slash.svg" alt="" class="mr-2 header-search-key-slash">

            <div class="Box position-absolute overflow-hidden d-none jump-to-suggestions js-jump-to-suggestions-container">
              
<ul class="d-none js-jump-to-suggestions-template-container">
  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-suggestion" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg height="16" width="16" class="octicon octicon-repo flex-shrink-0 js-jump-to-octicon-repo d-none" title="Repository" aria-label="Repository" viewBox="0 0 12 16" version="1.1" role="img"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-project flex-shrink-0 js-jump-to-octicon-project d-none" title="Project" aria-label="Project" viewBox="0 0 15 16" version="1.1" role="img"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 00-1 1v14a1 1 0 001 1h13a1 1 0 001-1V1a1 1 0 00-1-1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-search flex-shrink-0 js-jump-to-octicon-search d-none" title="Search" aria-label="Search" viewBox="0 0 16 16" version="1.1" role="img"><path fill-rule="evenodd" d="M15.7 13.3l-3.81-3.83A5.93 5.93 0 0013 6c0-3.31-2.69-6-6-6S1 2.69 1 6s2.69 6 6 6c1.3 0 2.48-.41 3.47-1.11l3.83 3.81c.19.2.45.3.7.3.25 0 .52-.09.7-.3a.996.996 0 000-1.41v.01zM7 10.7c-2.59 0-4.7-2.11-4.7-4.7 0-2.59 2.11-4.7 4.7-4.7 2.59 0 4.7 2.11 4.7 4.7 0 2.59-2.11 4.7-4.7 4.7z"/></svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

</ul>

<ul class="d-none js-jump-to-no-results-template-container">
  <li class="d-flex flex-justify-center flex-items-center f5 d-none js-jump-to-suggestion p-2">
    <span class="text-gray">No suggested jump to results</span>
  </li>
</ul>

<ul id="jump-to-results" role="listbox" class="p-0 m-0 js-navigation-container jump-to-suggestions-results-container js-jump-to-suggestions-results-container">
  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-scoped-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg height="16" width="16" class="octicon octicon-repo flex-shrink-0 js-jump-to-octicon-repo d-none" title="Repository" aria-label="Repository" viewBox="0 0 12 16" version="1.1" role="img"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-project flex-shrink-0 js-jump-to-octicon-project d-none" title="Project" aria-label="Project" viewBox="0 0 15 16" version="1.1" role="img"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 00-1 1v14a1 1 0 001 1h13a1 1 0 001-1V1a1 1 0 00-1-1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-search flex-shrink-0 js-jump-to-octicon-search d-none" title="Search" aria-label="Search" viewBox="0 0 16 16" version="1.1" role="img"><path fill-rule="evenodd" d="M15.7 13.3l-3.81-3.83A5.93 5.93 0 0013 6c0-3.31-2.69-6-6-6S1 2.69 1 6s2.69 6 6 6c1.3 0 2.48-.41 3.47-1.11l3.83 3.81c.19.2.45.3.7.3.25 0 .52-.09.7-.3a.996.996 0 000-1.41v.01zM7 10.7c-2.59 0-4.7-2.11-4.7-4.7 0-2.59 2.11-4.7 4.7-4.7 2.59 0 4.7 2.11 4.7 4.7 0 2.59-2.11 4.7-4.7 4.7z"/></svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-global-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg height="16" width="16" class="octicon octicon-repo flex-shrink-0 js-jump-to-octicon-repo d-none" title="Repository" aria-label="Repository" viewBox="0 0 12 16" version="1.1" role="img"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-project flex-shrink-0 js-jump-to-octicon-project d-none" title="Project" aria-label="Project" viewBox="0 0 15 16" version="1.1" role="img"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 00-1 1v14a1 1 0 001 1h13a1 1 0 001-1V1a1 1 0 00-1-1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-search flex-shrink-0 js-jump-to-octicon-search d-none" title="Search" aria-label="Search" viewBox="0 0 16 16" version="1.1" role="img"><path fill-rule="evenodd" d="M15.7 13.3l-3.81-3.83A5.93 5.93 0 0013 6c0-3.31-2.69-6-6-6S1 2.69 1 6s2.69 6 6 6c1.3 0 2.48-.41 3.47-1.11l3.83 3.81c.19.2.45.3.7.3.25 0 .52-.09.7-.3a.996.996 0 000-1.41v.01zM7 10.7c-2.59 0-4.7-2.11-4.7-4.7 0-2.59 2.11-4.7 4.7-4.7 2.59 0 4.7 2.11 4.7 4.7 0 2.59-2.11 4.7-4.7 4.7z"/></svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>


</ul>

            </div>
      </label>
</form>  </div>
</div>

          </div>

        <a href="/login?return_to=%2Ftailwindcss%2Ftailwindcss%2Fblame%2F2babe0cb23d9f0029bce928fb9b8fb5992785681%2Fstubs%2FdefaultConfig.stub.js"
          class="HeaderMenu-link no-underline mr-3"
          data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header menu&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/tailwindcss/tailwindcss/blame/2babe0cb23d9f0029bce928fb9b8fb5992785681/stubs/defaultConfig.stub.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="f9bb595ee07901c01e55ed0c69516aa1d75e4043b0c84303cda391bdb1e7fb4e"
          data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">
          Sign&nbsp;in
        </a>
          <a href="/join?source_repo=tailwindcss%2Ftailwindcss"
            class="HeaderMenu-link d-inline-block no-underline border border-gray-dark rounded-1 px-2 py-1"
            data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header menu&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/tailwindcss/tailwindcss/blame/2babe0cb23d9f0029bce928fb9b8fb5992785681/stubs/defaultConfig.stub.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="f9bb595ee07901c01e55ed0c69516aa1d75e4043b0c84303cda391bdb1e7fb4e"
            data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">
            Sign&nbsp;up
          </a>
      </div>
    </div>
  </div>
</header>

  </div>

  <div id="start-of-content" class="show-on-focus"></div>


    <div id="js-flash-container">

</div>


    






  <div class="application-main " data-commit-hovercards-enabled>
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode" class="">
    <main id="js-repo-pjax-container" data-pjax-container >
      

  




  









  <div class="pagehead repohead hx_repohead readability-menu bg-gray-light pb-0 pt-3">

    <div class="container-lg mb-4 px-3 d-flex">

      <div class="flex-auto min-width-0 width-fit mr-3">
        <h1 class="public  d-flex flex-wrap flex-items-center break-word float-none ">
    <svg class="octicon octicon-repo" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
  <span class="author ml-1 flex-self-stretch" itemprop="author">
    <a class="url fn" rel="author" data-hovercard-type="organization" data-hovercard-url="/orgs/tailwindcss/hovercard" href="/tailwindcss">tailwindcss</a>
  </span>
  <span class="path-divider flex-self-stretch">/</span>
  <strong itemprop="name" class="mr-2 flex-self-stretch">
    <a data-pjax="#js-repo-pjax-container" href="/tailwindcss/tailwindcss">tailwindcss</a>
  </strong>
  
</h1>


      </div>

      <ul class="pagehead-actions flex-shrink-0"  >




  <li>
    
  <a class="tooltipped tooltipped-s btn btn-sm btn-with-count" aria-label="You must be signed in to watch a repository" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;notification subscription menu watch&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/tailwindcss/tailwindcss/blame/2babe0cb23d9f0029bce928fb9b8fb5992785681/stubs/defaultConfig.stub.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="463c39736c9fcdf5b55acb237237180248521eb629e19997d22d53dc6ed547dc" href="/login?return_to=%2Ftailwindcss%2Ftailwindcss">
    <svg class="octicon octicon-eye v-align-text-bottom" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.06 2C3 2 0 8 0 8s3 6 8.06 6C13 14 16 8 16 8s-3-6-7.94-6zM8 12c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4zm2-4c0 1.11-.89 2-2 2-1.11 0-2-.89-2-2 0-1.11.89-2 2-2 1.11 0 2 .89 2 2z"/></svg>
    Watch
</a>    <a class="social-count" href="/tailwindcss/tailwindcss/watchers"
       aria-label="390 users are watching this repository">
      390
    </a>

  </li>

  <li>
        <a class="btn btn-sm btn-with-count tooltipped tooltipped-s" aria-label="You must be signed in to star a repository" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;star button&quot;,&quot;repository_id&quot;:106017343,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/tailwindcss/tailwindcss/blame/2babe0cb23d9f0029bce928fb9b8fb5992785681/stubs/defaultConfig.stub.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="7ad50f3a44e6f263f5bbedd713ba7c0d6d0104a3f84092c458c64c11ea651172" href="/login?return_to=%2Ftailwindcss%2Ftailwindcss">
      <svg aria-label="star" height="16" class="octicon octicon-star v-align-text-bottom" viewBox="0 0 14 16" version="1.1" width="14" role="img"><path fill-rule="evenodd" d="M14 6l-4.9-.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14 7 11.67 11.33 14l-.93-4.74L14 6z"/></svg>

      Star
</a>
    <a class="social-count js-social-count" href="/tailwindcss/tailwindcss/stargazers"
      aria-label="19919 users starred this repository">
      19.9k
    </a>

  </li>

  <li>
      <a class="btn btn-sm btn-with-count tooltipped tooltipped-s" aria-label="You must be signed in to fork a repository" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;repo details fork button&quot;,&quot;repository_id&quot;:106017343,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/tailwindcss/tailwindcss/blame/2babe0cb23d9f0029bce928fb9b8fb5992785681/stubs/defaultConfig.stub.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="5271f4006092e6027fee400bee7ba80698aa9fe41279d8be82ad072f449d9314" href="/login?return_to=%2Ftailwindcss%2Ftailwindcss">
        <svg class="octicon octicon-repo-forked v-align-text-bottom" viewBox="0 0 10 16" version="1.1" width="10" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8 1a1.993 1.993 0 00-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 002 1a1.993 1.993 0 00-1 3.72V6.5l3 3v1.78A1.993 1.993 0 005 15a1.993 1.993 0 001-3.72V9.5l3-3V4.72A1.993 1.993 0 008 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
        Fork
</a>
    <a href="/tailwindcss/tailwindcss/network/members" class="social-count"
       aria-label="890 users forked this repository">
      890
    </a>
  </li>
</ul>

    </div>
      
<nav class="hx_reponav reponav js-repo-nav js-sidenav-container-pjax clearfix container-lg px-3"
     itemscope
     itemtype="http://schema.org/BreadcrumbList"
    aria-label="Repository"
     data-pjax="#js-repo-pjax-container">

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a class="js-selected-navigation-item selected reponav-item" itemprop="url" data-hotkey="g c" aria-current="page" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages /tailwindcss/tailwindcss" href="/tailwindcss/tailwindcss">
      <div class="d-inline"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></div>
      <span itemprop="name">Code</span>
      <meta itemprop="position" content="1">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
      <a itemprop="url" data-hotkey="g i" class="js-selected-navigation-item reponav-item" data-selected-links="repo_issues repo_labels repo_milestones /tailwindcss/tailwindcss/issues" href="/tailwindcss/tailwindcss/issues">
        <div class="d-inline"><svg class="octicon octicon-issue-opened" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 011.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z"/></svg></div>
        <span itemprop="name">Issues</span>
        <span class="Counter">50</span>
        <meta itemprop="position" content="2">
</a>    </span>


  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a data-hotkey="g p" data-skip-pjax="true" itemprop="url" class="js-selected-navigation-item reponav-item" data-selected-links="repo_pulls checks /tailwindcss/tailwindcss/pulls" href="/tailwindcss/tailwindcss/pulls">
      <div class="d-inline"><svg class="octicon octicon-git-pull-request" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0010 15a1.993 1.993 0 001-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 00-1 3.72v6.56A1.993 1.993 0 002 15a1.993 1.993 0 001-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg></div>
      <span itemprop="name">Pull requests</span>
      <span class="Counter">11</span>
      <meta itemprop="position" content="4">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement" class="position-relative float-left">
      <a data-hotkey="g w" data-skip-pjax="true" class="js-selected-navigation-item reponav-item" data-selected-links="repo_actions /tailwindcss/tailwindcss/actions" href="/tailwindcss/tailwindcss/actions">
        <div class="d-inline"><svg class="octicon octicon-play" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M14 8A7 7 0 110 8a7 7 0 0114 0zm-8.223 3.482l4.599-3.066a.5.5 0 000-.832L5.777 4.518A.5.5 0 005 4.934v6.132a.5.5 0 00.777.416z"/></svg></div>
        Actions
</a>
    </span>

    <a data-hotkey="g b" class="js-selected-navigation-item reponav-item" data-selected-links="repo_projects new_repo_project repo_project /tailwindcss/tailwindcss/projects" href="/tailwindcss/tailwindcss/projects">
      <div class="d-inline"><svg class="octicon octicon-project" viewBox="0 0 15 16" version="1.1" width="15" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 00-1 1v14a1 1 0 001 1h13a1 1 0 001-1V1a1 1 0 00-1-1z"/></svg></div>
      Projects
      <span class="Counter" >0</span>
</a>

    <a data-skip-pjax="true" class="js-selected-navigation-item reponav-item" data-selected-links="security alerts policy token_scanning code_scanning /tailwindcss/tailwindcss/security/advisories" href="/tailwindcss/tailwindcss/security/advisories">
      <div class="d-inline"><svg class="octicon octicon-shield" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M0 2l7-2 7 2v6.02C14 12.69 8.69 16 7 16c-1.69 0-7-3.31-7-7.98V2zm1 .75L7 1l6 1.75v5.268C13 12.104 8.449 15 7 15c-1.449 0-6-2.896-6-6.982V2.75zm1 .75L7 2v12c-1.207 0-5-2.482-5-5.985V3.5z"/></svg></div>
      Security
</a>
    <a class="js-selected-navigation-item reponav-item" data-selected-links="repo_graphs repo_contributors dependency_graph pulse people /tailwindcss/tailwindcss/pulse" href="/tailwindcss/tailwindcss/pulse">
      <div class="d-inline"><svg class="octicon octicon-graph" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M16 14v1H0V0h1v14h15zM5 13H3V8h2v5zm4 0H7V3h2v10zm4 0h-2V6h2v7z"/></svg></div>
      Insights
</a>

</nav>


  </div>


<div class="container-lg clearfix new-discussion-timeline  px-3">
  <div class="repository-content ">

    
    

  <div class="wants-full-width-container"></div>

  <a class="d-none js-permalink-shortcut" data-hotkey="y" href="/tailwindcss/tailwindcss/blame/2babe0cb23d9f0029bce928fb9b8fb5992785681/stubs/defaultConfig.stub.js">Permalink</a>

  <div class="breadcrumb css-truncate blame-breadcrumb">
    <span id="blob-path" class="css-truncate-target"><span class="js-repo-root text-bold"><span class="js-path-segment"><a data-pjax="true" rel="nofollow" href="/tailwindcss/tailwindcss/tree/2babe0cb23d9f0029bce928fb9b8fb5992785681"><span>tailwindcss</span></a></span></span><span class="separator">/</span><span class="js-path-segment"><a data-pjax="true" rel="nofollow" href="/tailwindcss/tailwindcss/tree/2babe0cb23d9f0029bce928fb9b8fb5992785681/stubs"><span>stubs</span></a></span><span class="separator">/</span><strong class="final-path">defaultConfig.stub.js</strong></span>
    <clipboard-copy value="stubs/defaultConfig.stub.js" aria-label="Copy file path to clipboard" class="btn btn-sm">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>
  </div>

  <div class="line-age-legend float-right mt-n4 f6">
    <span>Newer</span>
    <ol class="d-inline-block mx-1 list-style-none">
        <li class="heat d-inline-block" data-heat="1"></li>
        <li class="heat d-inline-block" data-heat="2"></li>
        <li class="heat d-inline-block" data-heat="3"></li>
        <li class="heat d-inline-block" data-heat="4"></li>
        <li class="heat d-inline-block" data-heat="5"></li>
        <li class="heat d-inline-block" data-heat="6"></li>
        <li class="heat d-inline-block" data-heat="7"></li>
        <li class="heat d-inline-block" data-heat="8"></li>
        <li class="heat d-inline-block" data-heat="9"></li>
        <li class="heat d-inline-block" data-heat="10"></li>
    </ol>
    <span>Older</span>
  </div>

  <div class="file">
    <div class="file-header">
      <div class="file-actions">
        <div class="BtnGroup">
          <a id="raw-url" class="btn btn-sm BtnGroup-item" href="/tailwindcss/tailwindcss/raw/2babe0cb23d9f0029bce928fb9b8fb5992785681/stubs/defaultConfig.stub.js">Raw</a>
          <a class="btn btn-sm js-update-url-with-hash BtnGroup-item" href="/tailwindcss/tailwindcss/blob/2babe0cb23d9f0029bce928fb9b8fb5992785681/stubs/defaultConfig.stub.js">Normal view</a>
          <a rel="nofollow" class="btn btn-sm BtnGroup-item" href="/tailwindcss/tailwindcss/commits/2babe0cb23d9f0029bce928fb9b8fb5992785681/stubs/defaultConfig.stub.js">History</a>
        </div>
      </div>

  

      <div class="file-info">
        <svg class="octicon octicon-file" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M6 5H2V4h4v1zM2 8h7V7H2v1zm0 2h7V9H2v1zm0 2h7v-1H2v1zm10-7.5V14c0 .55-.45 1-1 1H1c-.55 0-1-.45-1-1V2c0-.55.45-1 1-1h7.5L12 4.5zM11 5L8 2H1v12h10V5z"/></svg>
        <span class="file-mode" title="File Mode">100644</span>
        <span class="file-info-divider"></span>
          604 lines (602 sloc)
          <span class="file-info-divider"></span>
        13.9 KB
      </div>
    </div>

    <div class="blob-wrapper">
      <div class="blame-container authors-2 highlight data js-file-line-container tab-size" data-tab-size="2">

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L1">1</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-c1">module</span>.<span class="pl-smi">exports</span> <span class="pl-k">=</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L2">2</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC2">  prefix<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span><span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L3">3</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC3">  important<span class="pl-k">:</span> <span class="pl-c1">false</span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L4">4</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC4">  separator<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>:<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L5">5</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC5">  theme<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/95e925ed0595cb6f1def42bf3382daffc541c3cb/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/95e925ed0595cb6f1def42bf3382daffc541c3cb">Move screens to top of config file</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:51:37Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/b5c3035bf17707999d3b692de46f94637eb0fb41/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L6">6</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC6">    screens<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L7">7</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC7">      sm<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>640px<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L8">8</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC8">      md<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>768px<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L9">9</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC9">      lg<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1024px<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L10">10</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC10">      xl<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1280px<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L11">11</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC11">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L12">12</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC12">    colors<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L13">13</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC13">      transparent<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>transparent<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L14">14</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC14">
</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84">Added a file that was removed during merge</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9e4f54a17f18b784a0d446b5c60ea5c9c8c34b3d/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L15">15</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC15">      black<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#000<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L16">16</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC16">      white<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fff<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L17">17</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC17">
</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84">Added a file that was removed during merge</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9e4f54a17f18b784a0d446b5c60ea5c9c8c34b3d/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L18">18</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC18">      gray<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L19">19</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC19">        <span class="pl-c1">100</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#f7fafc<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L20">20</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC20">        <span class="pl-c1">200</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#edf2f7<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L21">21</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC21">        <span class="pl-c1">300</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#e2e8f0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L22">22</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC22">        <span class="pl-c1">400</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#cbd5e0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L23">23</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC23">        <span class="pl-c1">500</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#a0aec0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L24">24</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC24">        <span class="pl-c1">600</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#718096<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L25">25</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC25">        <span class="pl-c1">700</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#4a5568<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L26">26</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC26">        <span class="pl-c1">800</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#2d3748<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L27">27</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC27">        <span class="pl-c1">900</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#1a202c<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L28">28</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC28">      },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L29">29</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC29">      red<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L30">30</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC30">        <span class="pl-c1">100</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fff5f5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L31">31</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC31">        <span class="pl-c1">200</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fed7d7<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L32">32</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC32">        <span class="pl-c1">300</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#feb2b2<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L33">33</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC33">        <span class="pl-c1">400</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fc8181<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L34">34</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC34">        <span class="pl-c1">500</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#f56565<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L35">35</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC35">        <span class="pl-c1">600</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#e53e3e<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L36">36</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC36">        <span class="pl-c1">700</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#c53030<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L37">37</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC37">        <span class="pl-c1">800</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#9b2c2c<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L38">38</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC38">        <span class="pl-c1">900</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#742a2a<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L39">39</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC39">      },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L40">40</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC40">      orange<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L41">41</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC41">        <span class="pl-c1">100</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fffaf0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L42">42</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC42">        <span class="pl-c1">200</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#feebc8<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L43">43</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC43">        <span class="pl-c1">300</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fbd38d<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L44">44</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC44">        <span class="pl-c1">400</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#f6ad55<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L45">45</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC45">        <span class="pl-c1">500</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#ed8936<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L46">46</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC46">        <span class="pl-c1">600</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#dd6b20<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L47">47</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC47">        <span class="pl-c1">700</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#c05621<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L48">48</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC48">        <span class="pl-c1">800</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#9c4221<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L49">49</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC49">        <span class="pl-c1">900</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#7b341e<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L50">50</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC50">      },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L51">51</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC51">      yellow<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L52">52</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC52">        <span class="pl-c1">100</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fffff0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L53">53</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC53">        <span class="pl-c1">200</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fefcbf<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L54">54</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC54">        <span class="pl-c1">300</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#faf089<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L55">55</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC55">        <span class="pl-c1">400</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#f6e05e<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L56">56</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC56">        <span class="pl-c1">500</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#ecc94b<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L57">57</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC57">        <span class="pl-c1">600</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#d69e2e<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L58">58</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC58">        <span class="pl-c1">700</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#b7791f<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L59">59</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC59">        <span class="pl-c1">800</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#975a16<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L60">60</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC60">        <span class="pl-c1">900</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#744210<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L61">61</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC61">      },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L62">62</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC62">      green<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L63">63</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC63">        <span class="pl-c1">100</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#f0fff4<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L64">64</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC64">        <span class="pl-c1">200</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#c6f6d5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L65">65</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC65">        <span class="pl-c1">300</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#9ae6b4<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L66">66</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC66">        <span class="pl-c1">400</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#68d391<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L67">67</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC67">        <span class="pl-c1">500</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#48bb78<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L68">68</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC68">        <span class="pl-c1">600</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#38a169<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L69">69</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC69">        <span class="pl-c1">700</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#2f855a<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L70">70</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC70">        <span class="pl-c1">800</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#276749<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L71">71</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC71">        <span class="pl-c1">900</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#22543d<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L72">72</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC72">      },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L73">73</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC73">      teal<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L74">74</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC74">        <span class="pl-c1">100</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#e6fffa<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L75">75</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC75">        <span class="pl-c1">200</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#b2f5ea<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L76">76</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC76">        <span class="pl-c1">300</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#81e6d9<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L77">77</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC77">        <span class="pl-c1">400</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#4fd1c5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L78">78</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC78">        <span class="pl-c1">500</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#38b2ac<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L79">79</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC79">        <span class="pl-c1">600</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#319795<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L80">80</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC80">        <span class="pl-c1">700</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#2c7a7b<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L81">81</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC81">        <span class="pl-c1">800</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#285e61<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L82">82</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC82">        <span class="pl-c1">900</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#234e52<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L83">83</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC83">      },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L84">84</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC84">      blue<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L85">85</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC85">        <span class="pl-c1">100</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#ebf8ff<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L86">86</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC86">        <span class="pl-c1">200</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#bee3f8<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L87">87</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC87">        <span class="pl-c1">300</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#90cdf4<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L88">88</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC88">        <span class="pl-c1">400</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#63b3ed<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L89">89</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC89">        <span class="pl-c1">500</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#4299e1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L90">90</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC90">        <span class="pl-c1">600</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#3182ce<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L91">91</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC91">        <span class="pl-c1">700</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#2b6cb0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L92">92</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC92">        <span class="pl-c1">800</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#2c5282<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L93">93</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC93">        <span class="pl-c1">900</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#2a4365<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L94">94</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC94">      },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L95">95</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC95">      indigo<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L96">96</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC96">        <span class="pl-c1">100</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#ebf4ff<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L97">97</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC97">        <span class="pl-c1">200</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#c3dafe<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L98">98</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC98">        <span class="pl-c1">300</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#a3bffa<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L99">99</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC99">        <span class="pl-c1">400</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#7f9cf5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L100">100</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC100">        <span class="pl-c1">500</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#667eea<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L101">101</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC101">        <span class="pl-c1">600</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#5a67d8<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L102">102</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC102">        <span class="pl-c1">700</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#4c51bf<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L103">103</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC103">        <span class="pl-c1">800</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#434190<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L104">104</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC104">        <span class="pl-c1">900</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#3c366b<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L105">105</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC105">      },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L106">106</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC106">      purple<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L107">107</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC107">        <span class="pl-c1">100</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#faf5ff<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L108">108</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC108">        <span class="pl-c1">200</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#e9d8fd<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L109">109</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC109">        <span class="pl-c1">300</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#d6bcfa<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L110">110</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC110">        <span class="pl-c1">400</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#b794f4<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L111">111</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC111">        <span class="pl-c1">500</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#9f7aea<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L112">112</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC112">        <span class="pl-c1">600</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#805ad5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L113">113</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC113">        <span class="pl-c1">700</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#6b46c1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L114">114</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC114">        <span class="pl-c1">800</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#553c9a<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L115">115</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC115">        <span class="pl-c1">900</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#44337a<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L116">116</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC116">      },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L117">117</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC117">      pink<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L118">118</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC118">        <span class="pl-c1">100</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fff5f7<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L119">119</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC119">        <span class="pl-c1">200</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fed7e2<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L120">120</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC120">        <span class="pl-c1">300</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#fbb6ce<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L121">121</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC121">        <span class="pl-c1">400</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#f687b3<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L122">122</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC122">        <span class="pl-c1">500</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#ed64a6<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L123">123</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC123">        <span class="pl-c1">600</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#d53f8c<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L124">124</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC124">        <span class="pl-c1">700</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#b83280<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L125">125</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC125">        <span class="pl-c1">800</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#97266d<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L126">126</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC126">        <span class="pl-c1">900</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>#702459<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L127">127</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC127">      },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L128">128</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC128">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L129">129</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC129">    spacing<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L130">130</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC130">      px<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1px<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L131">131</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC131">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L132">132</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC132">      <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.25rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L133">133</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC133">      <span class="pl-s"><span class="pl-pds">&#39;</span>2<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.5rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L134">134</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC134">      <span class="pl-s"><span class="pl-pds">&#39;</span>3<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.75rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L135">135</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC135">      <span class="pl-s"><span class="pl-pds">&#39;</span>4<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L136">136</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC136">      <span class="pl-s"><span class="pl-pds">&#39;</span>5<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.25rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L137">137</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC137">      <span class="pl-s"><span class="pl-pds">&#39;</span>6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.5rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L138">138</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC138">      <span class="pl-s"><span class="pl-pds">&#39;</span>8<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>2rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L139">139</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC139">      <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>2.5rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L140">140</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC140">      <span class="pl-s"><span class="pl-pds">&#39;</span>12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>3rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L141">141</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC141">      <span class="pl-s"><span class="pl-pds">&#39;</span>16<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>4rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L142">142</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC142">      <span class="pl-s"><span class="pl-pds">&#39;</span>20<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>5rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L143">143</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC143">      <span class="pl-s"><span class="pl-pds">&#39;</span>24<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>6rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L144">144</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC144">      <span class="pl-s"><span class="pl-pds">&#39;</span>32<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>8rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L145">145</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC145">      <span class="pl-s"><span class="pl-pds">&#39;</span>40<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>10rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L146">146</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC146">      <span class="pl-s"><span class="pl-pds">&#39;</span>48<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>12rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L147">147</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC147">      <span class="pl-s"><span class="pl-pds">&#39;</span>56<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>14rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L148">148</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC148">      <span class="pl-s"><span class="pl-pds">&#39;</span>64<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>16rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L149">149</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC149">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L150">150</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC150">    <span class="pl-en">backgroundColor</span><span class="pl-k">:</span> <span class="pl-smi">theme</span> <span class="pl-k">=&gt;</span> <span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>colors<span class="pl-pds">&#39;</span></span>),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L151">151</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC151">    backgroundPosition<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L152">152</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC152">      bottom<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>bottom<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L153">153</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC153">      center<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>center<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L154">154</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC154">      left<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>left<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L155">155</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC155">      <span class="pl-s"><span class="pl-pds">&#39;</span>left-bottom<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>left bottom<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L156">156</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC156">      <span class="pl-s"><span class="pl-pds">&#39;</span>left-top<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>left top<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L157">157</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC157">      right<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>right<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L158">158</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC158">      <span class="pl-s"><span class="pl-pds">&#39;</span>right-bottom<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>right bottom<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L159">159</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC159">      <span class="pl-s"><span class="pl-pds">&#39;</span>right-top<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>right top<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L160">160</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC160">      top<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>top<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L161">161</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC161">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L162">162</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC162">    backgroundSize<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L163">163</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC163">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L164">164</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC164">      cover<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>cover<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L165">165</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC165">      contain<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>contain<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L166">166</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC166">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L167">167</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC167">    <span class="pl-en">borderColor</span><span class="pl-k">:</span> <span class="pl-smi">theme</span> <span class="pl-k">=&gt;</span> ({</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L168">168</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC168">      <span class="pl-k">...</span><span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>colors<span class="pl-pds">&#39;</span></span>),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L169">169</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC169">      default<span class="pl-k">:</span> <span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>colors.gray.300<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>currentColor<span class="pl-pds">&#39;</span></span>),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L170">170</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC170">    }),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L171">171</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC171">    borderRadius<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L172">172</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC172">      none<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L173">173</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC173">      sm<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.125rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L174">174</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC174">      default<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.25rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L175">175</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC175">      lg<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.5rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L176">176</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC176">      full<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>9999px<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L177">177</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC177">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L178">178</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC178">    borderWidth<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L179">179</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC179">      default<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1px<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L180">180</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC180">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L181">181</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC181">      <span class="pl-s"><span class="pl-pds">&#39;</span>2<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>2px<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L182">182</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC182">      <span class="pl-s"><span class="pl-pds">&#39;</span>4<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>4px<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L183">183</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC183">      <span class="pl-s"><span class="pl-pds">&#39;</span>8<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>8px<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L184">184</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC184">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L185">185</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC185">    boxShadow<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e7c08c48e595db68a95fd95fb482e8f3f6f974c0/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e7c08c48e595db68a95fd95fb482e8f3f6f974c0">Fix code style</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-24T00:21:48Z" class="no-wrap">Dec 24, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/cd63948fa277a676bb2b73398f8a74b14c6149ee/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L186">186</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC186">      default<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L187">187</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC187">      md<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L188">188</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC188">      lg<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L189">189</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC189">      xl<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L190">190</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC190">      <span class="pl-s"><span class="pl-pds">&#39;</span>2xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0 25px 50px -12px rgba(0, 0, 0, 0.25)<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L191">191</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC191">      inner<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>inset 0 2px 4px 0 rgba(0, 0, 0, 0.06)<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L192">192</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC192">      outline<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0 0 0 3px rgba(66, 153, 225, 0.5)<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L193">193</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC193">      none<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>none<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L194">194</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC194">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L195">195</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC195">    container<span class="pl-k">:</span> {},</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L196">196</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC196">    cursor<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L197">197</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC197">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L198">198</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC198">      default<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>default<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L199">199</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC199">      pointer<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>pointer<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L200">200</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC200">      wait<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>wait<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L201">201</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC201">      text<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>text<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L202">202</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC202">      move<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>move<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L203">203</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC203">      <span class="pl-s"><span class="pl-pds">&#39;</span>not-allowed<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>not-allowed<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L204">204</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC204">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L205">205</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC205">    fill<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L206">206</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC206">      current<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>currentColor<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L207">207</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC207">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L208">208</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC208">    flex<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L209">209</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC209">      <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1 1 0%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L210">210</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC210">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1 1 auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L211">211</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC211">      initial<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0 1 auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L212">212</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC212">      none<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>none<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L213">213</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC213">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L214">214</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC214">    flexGrow<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L215">215</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC215">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L216">216</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC216">      default<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L217">217</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC217">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L218">218</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC218">    flexShrink<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L219">219</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC219">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L220">220</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC220">      default<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L221">221</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC221">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L222">222</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC222">    fontFamily<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L223">223</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC223">      sans<span class="pl-k">:</span> [</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start AvatarStack--two">
  <div class="AvatarStack-body" aria-label="GeoffSelby and adamwathan (non-author committer)">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/GeoffSelby/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/GeoffSelby">
          <img height="20" width="20" alt="@GeoffSelby" src="https://avatars3.githubusercontent.com/u/6684498?s=60&amp;v=4" />
</a>        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/fe7098a3c093c2d4daeb58b59f301f402a2ee359/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/fe7098a3c093c2d4daeb58b59f301f402a2ee359">Add Inter to `sans` font stack</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-24T01:07:26Z" class="no-wrap">Dec 24, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/b630d965f6fb2d470005ad49a66b2e53c3e268d7/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L224">224</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC224">        <span class="pl-s"><span class="pl-pds">&#39;</span>Inter<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L225">225</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC225">        <span class="pl-s"><span class="pl-pds">&#39;</span>-apple-system<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84">Added a file that was removed during merge</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9e4f54a17f18b784a0d446b5c60ea5c9c8c34b3d/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L226">226</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC226">        <span class="pl-s"><span class="pl-pds">&#39;</span>BlinkMacSystemFont<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L227">227</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC227">        <span class="pl-s"><span class="pl-pds">&#39;</span>&quot;Segoe UI&quot;<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L228">228</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC228">        <span class="pl-s"><span class="pl-pds">&#39;</span>Roboto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84">Added a file that was removed during merge</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9e4f54a17f18b784a0d446b5c60ea5c9c8c34b3d/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L229">229</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC229">        <span class="pl-s"><span class="pl-pds">&#39;</span>&quot;Helvetica Neue&quot;<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L230">230</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC230">        <span class="pl-s"><span class="pl-pds">&#39;</span>Arial<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L231">231</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC231">        <span class="pl-s"><span class="pl-pds">&#39;</span>&quot;Noto Sans&quot;<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L232">232</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC232">        <span class="pl-s"><span class="pl-pds">&#39;</span>sans-serif<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84">Added a file that was removed during merge</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9e4f54a17f18b784a0d446b5c60ea5c9c8c34b3d/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L233">233</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC233">        <span class="pl-s"><span class="pl-pds">&#39;</span>&quot;Apple Color Emoji&quot;<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L234">234</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC234">        <span class="pl-s"><span class="pl-pds">&#39;</span>&quot;Segoe UI Emoji&quot;<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L235">235</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC235">        <span class="pl-s"><span class="pl-pds">&#39;</span>&quot;Segoe UI Symbol&quot;<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L236">236</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC236">        <span class="pl-s"><span class="pl-pds">&#39;</span>&quot;Noto Color Emoji&quot;<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L237">237</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC237">      ],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7">Add first pass of transform utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-22T20:25:34Z" class="no-wrap">Dec 22, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/ecd1d102643e1c259d00b4f392bbdc71a86d8615/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L238">238</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC238">      serif<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>Georgia<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>Cambria<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&quot;Times New Roman&quot;<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>Times<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>serif<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e7c08c48e595db68a95fd95fb482e8f3f6f974c0/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e7c08c48e595db68a95fd95fb482e8f3f6f974c0">Fix code style</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-24T00:21:48Z" class="no-wrap">Dec 24, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/cd63948fa277a676bb2b73398f8a74b14c6149ee/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L239">239</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC239">      mono<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>Menlo<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>Monaco<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>Consolas<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&quot;Liberation Mono&quot;<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&quot;Courier New&quot;<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>monospace<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L240">240</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC240">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L241">241</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC241">    fontSize<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c98cc12d35eae3318fc32c92e6d4bd04364ef988/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c98cc12d35eae3318fc32c92e6d4bd04364ef988">Remove dependency on perfectionist, implement simple formatting from …</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-04-16T15:43:17Z" class="no-wrap">Apr 16, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/63c3ca2708c5ab95aa75ab5dd22e716b60fe27ef/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L242">242</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC242">      xs<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.75rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L243">243</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC243">      sm<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.875rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L244">244</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC244">      base<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L245">245</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC245">      lg<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.125rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L246">246</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC246">      xl<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.25rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L247">247</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC247">      <span class="pl-s"><span class="pl-pds">&#39;</span>2xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.5rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L248">248</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC248">      <span class="pl-s"><span class="pl-pds">&#39;</span>3xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.875rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L249">249</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC249">      <span class="pl-s"><span class="pl-pds">&#39;</span>4xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>2.25rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L250">250</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC250">      <span class="pl-s"><span class="pl-pds">&#39;</span>5xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>3rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84">Added a file that was removed during merge</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9e4f54a17f18b784a0d446b5c60ea5c9c8c34b3d/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L251">251</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC251">      <span class="pl-s"><span class="pl-pds">&#39;</span>6xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>4rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L252">252</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC252">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L253">253</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC253">    fontWeight<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/5804a996c2e399d8249d5044c21b325507ae2b12/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/5804a996c2e399d8249d5044c21b325507ae2b12">Quote all config values for consistency</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-04-27T15:51:02Z" class="no-wrap">Apr 27, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/a92faeefac4d9fc0ac498d707406130960821523/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L254">254</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC254">      hairline<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L255">255</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC255">      thin<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>200<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L256">256</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC256">      light<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>300<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L257">257</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC257">      normal<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>400<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L258">258</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC258">      medium<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>500<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L259">259</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC259">      semibold<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>600<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L260">260</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC260">      bold<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>700<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L261">261</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC261">      extrabold<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>800<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L262">262</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC262">      black<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>900<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L263">263</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC263">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L264">264</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC264">    <span class="pl-en">height</span><span class="pl-k">:</span> <span class="pl-smi">theme</span> <span class="pl-k">=&gt;</span> ({</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L265">265</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC265">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L266">266</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC266">      <span class="pl-k">...</span><span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>spacing<span class="pl-pds">&#39;</span></span>),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L267">267</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC267">      full<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L268">268</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC268">      <span class="pl-c1">screen</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100vh<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L269">269</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC269">    }),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L270">270</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC270">    inset<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L271">271</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC271">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L272">272</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC272">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L273">273</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC273">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L274">274</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC274">    letterSpacing<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="Log1x">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/Log1x/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/Log1x">
          <img height="20" width="20" alt="@Log1x" src="https://avatars3.githubusercontent.com/u/5745907?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/520188a5d0a355d88672af6f3aba0e1396ab62ec/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/520188a5d0a355d88672af6f3aba0e1396ab62ec">Add missing trailing zeros</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-04-23T08:49:07Z" class="no-wrap">Apr 23, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/e9b4014131bcb81212fd534addeca49f1f754930/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L275">275</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC275">      tighter<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>-0.05em<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L276">276</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC276">      tight<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>-0.025em<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L277">277</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC277">      normal<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c98cc12d35eae3318fc32c92e6d4bd04364ef988/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c98cc12d35eae3318fc32c92e6d4bd04364ef988">Remove dependency on perfectionist, implement simple formatting from …</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-04-16T15:43:17Z" class="no-wrap">Apr 16, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/63c3ca2708c5ab95aa75ab5dd22e716b60fe27ef/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L278">278</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC278">      wide<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.025em<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L279">279</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC279">      wider<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.05em<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L280">280</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC280">      widest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.1em<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L281">281</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC281">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L282">282</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC282">    lineHeight<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L283">283</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC283">      none<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L284">284</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC284">      tight<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.25<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L285">285</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC285">      snug<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.375<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L286">286</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC286">      normal<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L287">287</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC287">      relaxed<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.625<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L288">288</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC288">      loose<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>2<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L289">289</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC289">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L290">290</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC290">    listStyleType<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L291">291</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC291">      none<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>none<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L292">292</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC292">      disc<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>disc<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L293">293</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC293">      decimal<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>decimal<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L294">294</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC294">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L295">295</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC295">    <span class="pl-en">margin</span><span class="pl-k">:</span> (<span class="pl-smi">theme</span>, { negative }) <span class="pl-k">=&gt;</span> ({</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L296">296</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC296">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/da10af26ebcd3f4013e6fd97dd031edb2c60bd02/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/da10af26ebcd3f4013e6fd97dd031edb2c60bd02">Update defaultConfig to use theme function</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-16T20:28:39Z" class="no-wrap">Mar 16, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/fcd0f364db6faf4b6e6cae57f524c29b7a89be60/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L297">297</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC297">      <span class="pl-k">...</span><span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>spacing<span class="pl-pds">&#39;</span></span>),</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L298">298</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC298">      <span class="pl-k">...</span><span class="pl-en">negative</span>(<span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>spacing<span class="pl-pds">&#39;</span></span>)),</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L299">299</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC299">    }),</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L300">300</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC300">    maxHeight<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L301">301</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC301">      full<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L302">302</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC302">      <span class="pl-c1">screen</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100vh<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L303">303</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC303">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L304">304</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC304">    maxWidth<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L305">305</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC305">      xs<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>20rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L306">306</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC306">      sm<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>24rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L307">307</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC307">      md<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>28rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L308">308</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC308">      lg<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>32rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L309">309</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC309">      xl<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>36rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L310">310</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC310">      <span class="pl-s"><span class="pl-pds">&#39;</span>2xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>42rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L311">311</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC311">      <span class="pl-s"><span class="pl-pds">&#39;</span>3xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>48rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L312">312</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC312">      <span class="pl-s"><span class="pl-pds">&#39;</span>4xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>56rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L313">313</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC313">      <span class="pl-s"><span class="pl-pds">&#39;</span>5xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>64rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L314">314</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC314">      <span class="pl-s"><span class="pl-pds">&#39;</span>6xl<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>72rem<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L315">315</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC315">      full<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L316">316</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC316">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L317">317</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC317">    minHeight<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L318">318</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC318">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L319">319</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC319">      full<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L320">320</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC320">      <span class="pl-c1">screen</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100vh<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L321">321</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC321">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L322">322</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC322">    minWidth<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L323">323</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC323">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L324">324</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC324">      full<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L325">325</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC325">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L326">326</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC326">    objectPosition<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L327">327</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC327">      bottom<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>bottom<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L328">328</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC328">      center<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>center<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L329">329</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC329">      left<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>left<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L330">330</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC330">      <span class="pl-s"><span class="pl-pds">&#39;</span>left-bottom<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>left bottom<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L331">331</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC331">      <span class="pl-s"><span class="pl-pds">&#39;</span>left-top<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>left top<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L332">332</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC332">      right<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>right<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L333">333</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC333">      <span class="pl-s"><span class="pl-pds">&#39;</span>right-bottom<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>right bottom<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L334">334</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC334">      <span class="pl-s"><span class="pl-pds">&#39;</span>right-top<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>right top<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L335">335</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC335">      top<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>top<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L336">336</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC336">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L337">337</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC337">    opacity<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L338">338</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC338">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c98cc12d35eae3318fc32c92e6d4bd04364ef988/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c98cc12d35eae3318fc32c92e6d4bd04364ef988">Remove dependency on perfectionist, implement simple formatting from …</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-04-16T15:43:17Z" class="no-wrap">Apr 16, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/63c3ca2708c5ab95aa75ab5dd22e716b60fe27ef/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L339">339</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC339">      <span class="pl-s"><span class="pl-pds">&#39;</span>25<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.25<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L340">340</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC340">      <span class="pl-s"><span class="pl-pds">&#39;</span>50<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L341">341</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC341">      <span class="pl-s"><span class="pl-pds">&#39;</span>75<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0.75<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L342">342</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC342">      <span class="pl-s"><span class="pl-pds">&#39;</span>100<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L343">343</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC343">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/a92faeefac4d9fc0ac498d707406130960821523/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/a92faeefac4d9fc0ac498d707406130960821523">Fix conflicts, update tests</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-04-27T15:37:20Z" class="no-wrap">Apr 27, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/e9d8d7f45f4c5b65f8c5fd7cd980b44ec411c2b3/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L344">344</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC344">    order<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/84cf0a1ca10d27e6b2e6bbc04ee6012af423387b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/84cf0a1ca10d27e6b2e6bbc04ee6012af423387b">Use 9999 for both order-first and order-last</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-10T11:50:49Z" class="no-wrap">May 10, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/a7aedde4ab4f666277a2ee7ba2b1061e9da69f6f/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L345">345</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC345">      first<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>-9999<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L346">346</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC346">      last<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>9999<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/a92faeefac4d9fc0ac498d707406130960821523/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/a92faeefac4d9fc0ac498d707406130960821523">Fix conflicts, update tests</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-04-27T15:37:20Z" class="no-wrap">Apr 27, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/e9d8d7f45f4c5b65f8c5fd7cd980b44ec411c2b3/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L347">347</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC347">      none<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L348">348</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC348">      <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L349">349</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC349">      <span class="pl-s"><span class="pl-pds">&#39;</span>2<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>2<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L350">350</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC350">      <span class="pl-s"><span class="pl-pds">&#39;</span>3<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>3<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L351">351</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC351">      <span class="pl-s"><span class="pl-pds">&#39;</span>4<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>4<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L352">352</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC352">      <span class="pl-s"><span class="pl-pds">&#39;</span>5<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L353">353</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC353">      <span class="pl-s"><span class="pl-pds">&#39;</span>6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>6<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L354">354</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC354">      <span class="pl-s"><span class="pl-pds">&#39;</span>7<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>7<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L355">355</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC355">      <span class="pl-s"><span class="pl-pds">&#39;</span>8<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>8<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L356">356</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC356">      <span class="pl-s"><span class="pl-pds">&#39;</span>9<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>9<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L357">357</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC357">      <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L358">358</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC358">      <span class="pl-s"><span class="pl-pds">&#39;</span>11<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>11<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L359">359</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC359">      <span class="pl-s"><span class="pl-pds">&#39;</span>12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>12<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L360">360</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC360">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L361">361</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC361">    <span class="pl-en">padding</span><span class="pl-k">:</span> <span class="pl-smi">theme</span> <span class="pl-k">=&gt;</span> <span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>spacing<span class="pl-pds">&#39;</span></span>),</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="8">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/d2d081cba133736343d4d4d14c14fde712304de0/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/d2d081cba133736343d4d4d14c14fde712304de0">Add placeholder color utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="8"><time-ago datetime="2019-08-06T14:07:27Z" class="no-wrap">Aug 6, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/8331d9fb24b94623931d4ff658d0828d7c016a14/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L362">362</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC362">    <span class="pl-en">placeholderColor</span><span class="pl-k">:</span> <span class="pl-smi">theme</span> <span class="pl-k">=&gt;</span> <span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>colors<span class="pl-pds">&#39;</span></span>),</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L363">363</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC363">    stroke<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L364">364</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC364">      current<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>currentColor<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L365">365</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC365">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L366">366</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC366">    <span class="pl-en">textColor</span><span class="pl-k">:</span> <span class="pl-smi">theme</span> <span class="pl-k">=&gt;</span> <span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>colors<span class="pl-pds">&#39;</span></span>),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L367">367</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC367">    <span class="pl-en">width</span><span class="pl-k">:</span> <span class="pl-smi">theme</span> <span class="pl-k">=&gt;</span> ({</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L368">368</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC368">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L369">369</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC369">      <span class="pl-k">...</span><span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>spacing<span class="pl-pds">&#39;</span></span>),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L370">370</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC370">      <span class="pl-s"><span class="pl-pds">&#39;</span>1/2<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>50%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="8">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157">Increase precision of percentage widths</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="8"><time-ago datetime="2019-06-08T12:39:39Z" class="no-wrap">Jun 8, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/c4b893bfa7ca781dd319292c1c912abe3d60e514/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L371">371</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC371">      <span class="pl-s"><span class="pl-pds">&#39;</span>1/3<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>33.333333%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L372">372</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC372">      <span class="pl-s"><span class="pl-pds">&#39;</span>2/3<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>66.666667%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L373">373</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC373">      <span class="pl-s"><span class="pl-pds">&#39;</span>1/4<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>25%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L374">374</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC374">      <span class="pl-s"><span class="pl-pds">&#39;</span>2/4<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>50%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L375">375</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC375">      <span class="pl-s"><span class="pl-pds">&#39;</span>3/4<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>75%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L376">376</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC376">      <span class="pl-s"><span class="pl-pds">&#39;</span>1/5<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>20%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L377">377</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC377">      <span class="pl-s"><span class="pl-pds">&#39;</span>2/5<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>40%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L378">378</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC378">      <span class="pl-s"><span class="pl-pds">&#39;</span>3/5<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>60%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L379">379</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC379">      <span class="pl-s"><span class="pl-pds">&#39;</span>4/5<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>80%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="8">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157">Increase precision of percentage widths</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="8"><time-ago datetime="2019-06-08T12:39:39Z" class="no-wrap">Jun 8, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/c4b893bfa7ca781dd319292c1c912abe3d60e514/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L380">380</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC380">      <span class="pl-s"><span class="pl-pds">&#39;</span>1/6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>16.666667%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L381">381</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC381">      <span class="pl-s"><span class="pl-pds">&#39;</span>2/6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>33.333333%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L382">382</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC382">      <span class="pl-s"><span class="pl-pds">&#39;</span>3/6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>50%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="8">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157">Increase precision of percentage widths</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="8"><time-ago datetime="2019-06-08T12:39:39Z" class="no-wrap">Jun 8, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/c4b893bfa7ca781dd319292c1c912abe3d60e514/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L383">383</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC383">      <span class="pl-s"><span class="pl-pds">&#39;</span>4/6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>66.666667%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L384">384</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC384">      <span class="pl-s"><span class="pl-pds">&#39;</span>5/6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>83.333333%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L385">385</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC385">      <span class="pl-s"><span class="pl-pds">&#39;</span>1/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>8.333333%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L386">386</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC386">      <span class="pl-s"><span class="pl-pds">&#39;</span>2/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>16.666667%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L387">387</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC387">      <span class="pl-s"><span class="pl-pds">&#39;</span>3/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>25%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="8">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157">Increase precision of percentage widths</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="8"><time-ago datetime="2019-06-08T12:39:39Z" class="no-wrap">Jun 8, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/c4b893bfa7ca781dd319292c1c912abe3d60e514/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L388">388</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC388">      <span class="pl-s"><span class="pl-pds">&#39;</span>4/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>33.333333%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L389">389</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC389">      <span class="pl-s"><span class="pl-pds">&#39;</span>5/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>41.666667%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L390">390</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC390">      <span class="pl-s"><span class="pl-pds">&#39;</span>6/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>50%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="8">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157">Increase precision of percentage widths</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="8"><time-ago datetime="2019-06-08T12:39:39Z" class="no-wrap">Jun 8, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/c4b893bfa7ca781dd319292c1c912abe3d60e514/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L391">391</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC391">      <span class="pl-s"><span class="pl-pds">&#39;</span>7/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>58.333333%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L392">392</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC392">      <span class="pl-s"><span class="pl-pds">&#39;</span>8/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>66.666667%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L393">393</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC393">      <span class="pl-s"><span class="pl-pds">&#39;</span>9/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>75%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="8">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/4549e2d1f1199bf65cb4fafdc04a426edb0a8157">Increase precision of percentage widths</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="8"><time-ago datetime="2019-06-08T12:39:39Z" class="no-wrap">Jun 8, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/c4b893bfa7ca781dd319292c1c912abe3d60e514/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L394">394</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC394">      <span class="pl-s"><span class="pl-pds">&#39;</span>10/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>83.333333%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L395">395</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC395">      <span class="pl-s"><span class="pl-pds">&#39;</span>11/12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>91.666667%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L396">396</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC396">      full<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L397">397</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC397">      <span class="pl-c1">screen</span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100vw<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L398">398</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC398">    }),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L399">399</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC399">    zIndex<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84">Added a file that was removed during merge</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9e4f54a17f18b784a0d446b5c60ea5c9c8c34b3d/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L400">400</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC400">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c65e41b92ea5da3be3742a60764161d3b849366c">Sort the theme keys in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T14:32:10Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/6c876071c5b0517f95336a21938b97ec572b0713/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L401">401</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC401">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L402">402</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC402">      <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L403">403</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC403">      <span class="pl-s"><span class="pl-pds">&#39;</span>20<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>20<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L404">404</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC404">      <span class="pl-s"><span class="pl-pds">&#39;</span>30<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>30<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L405">405</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC405">      <span class="pl-s"><span class="pl-pds">&#39;</span>40<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>40<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L406">406</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC406">      <span class="pl-s"><span class="pl-pds">&#39;</span>50<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>50<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84">Added a file that was removed during merge</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9e4f54a17f18b784a0d446b5c60ea5c9c8c34b3d/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L407">407</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC407">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="5">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/d33fbc489560ce7f9ed8c0b8b205d2e4b882af73/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/d33fbc489560ce7f9ed8c0b8b205d2e4b882af73">Rename gap plugins to remove grid prefix, manually include old proper…</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="5"><time-ago datetime="2019-12-25T18:16:04Z" class="no-wrap">Dec 25, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/d075773c67f5922d824a21e23d89455319365bd0/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L408">408</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC408">    <span class="pl-en">gap</span><span class="pl-k">:</span> <span class="pl-smi">theme</span> <span class="pl-k">=&gt;</span> <span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>spacing<span class="pl-pds">&#39;</span></span>),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L409">409</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC409">    rowGap<span class="pl-k">:</span> {},</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L410">410</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC410">    columnGap<span class="pl-k">:</span> {},</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6">Add CSS grid utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-24T17:58:27Z" class="no-wrap">Dec 24, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/009f52d07fbf8fdaa10a54c3e118848ecc212a83/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L411">411</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC411">    gridTemplateColumns<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="5">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/2babe0cb23d9f0029bce928fb9b8fb5992785681/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/2babe0cb23d9f0029bce928fb9b8fb5992785681">Add none/auto values for grid utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="5"><time-ago datetime="2019-12-30T12:47:45Z" class="no-wrap">Dec 30, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/505d03811ce784b7f47175cec7f7499df86cfe32/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L412">412</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC412">      none<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>none<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="5">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/d075773c67f5922d824a21e23d89455319365bd0/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/d075773c67f5922d824a21e23d89455319365bd0">Use minmax to ensure default grid columns are always equal width</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="5"><time-ago datetime="2019-12-25T18:04:34Z" class="no-wrap">Dec 25, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/a552eb185b8ca0daa3f6bbcd0193d4df7b973d73/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L413">413</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC413">      <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(1, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L414">414</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC414">      <span class="pl-s"><span class="pl-pds">&#39;</span>2<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(2, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L415">415</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC415">      <span class="pl-s"><span class="pl-pds">&#39;</span>3<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(3, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L416">416</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC416">      <span class="pl-s"><span class="pl-pds">&#39;</span>4<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(4, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L417">417</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC417">      <span class="pl-s"><span class="pl-pds">&#39;</span>5<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(5, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L418">418</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC418">      <span class="pl-s"><span class="pl-pds">&#39;</span>6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(6, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L419">419</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC419">      <span class="pl-s"><span class="pl-pds">&#39;</span>7<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(7, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L420">420</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC420">      <span class="pl-s"><span class="pl-pds">&#39;</span>8<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(8, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L421">421</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC421">      <span class="pl-s"><span class="pl-pds">&#39;</span>9<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(9, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L422">422</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC422">      <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(10, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L423">423</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC423">      <span class="pl-s"><span class="pl-pds">&#39;</span>11<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(11, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L424">424</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC424">      <span class="pl-s"><span class="pl-pds">&#39;</span>12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>repeat(12, minmax(0, 1fr))<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6">Add CSS grid utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-24T17:58:27Z" class="no-wrap">Dec 24, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/009f52d07fbf8fdaa10a54c3e118848ecc212a83/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L425">425</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC425">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L426">426</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC426">    gridColumn<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="5">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/2babe0cb23d9f0029bce928fb9b8fb5992785681/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/2babe0cb23d9f0029bce928fb9b8fb5992785681">Add none/auto values for grid utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="5"><time-ago datetime="2019-12-30T12:47:45Z" class="no-wrap">Dec 30, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/505d03811ce784b7f47175cec7f7499df86cfe32/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L427">427</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC427">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6">Add CSS grid utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-24T17:58:27Z" class="no-wrap">Dec 24, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/009f52d07fbf8fdaa10a54c3e118848ecc212a83/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L428">428</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC428">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-1<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 1 / span 1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L429">429</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC429">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-2<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 2 / span 2<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L430">430</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC430">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-3<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 3 / span 3<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L431">431</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC431">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-4<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 4 / span 4<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L432">432</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC432">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-5<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 5 / span 5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L433">433</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC433">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 6 / span 6<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L434">434</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC434">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-7<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 7 / span 7<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L435">435</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC435">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-8<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 8 / span 8<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L436">436</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC436">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-9<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 9 / span 9<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L437">437</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC437">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-10<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 10 / span 10<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L438">438</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC438">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-11<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 11 / span 11<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L439">439</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC439">      <span class="pl-s"><span class="pl-pds">&#39;</span>span-12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>span 12 / span 12<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L440">440</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC440">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L441">441</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC441">    gridColumnStart<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="5">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/2babe0cb23d9f0029bce928fb9b8fb5992785681/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/2babe0cb23d9f0029bce928fb9b8fb5992785681">Add none/auto values for grid utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="5"><time-ago datetime="2019-12-30T12:47:45Z" class="no-wrap">Dec 30, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/505d03811ce784b7f47175cec7f7499df86cfe32/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L442">442</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC442">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6">Add CSS grid utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-24T17:58:27Z" class="no-wrap">Dec 24, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/009f52d07fbf8fdaa10a54c3e118848ecc212a83/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L443">443</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC443">      <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L444">444</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC444">      <span class="pl-s"><span class="pl-pds">&#39;</span>2<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>2<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L445">445</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC445">      <span class="pl-s"><span class="pl-pds">&#39;</span>3<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>3<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L446">446</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC446">      <span class="pl-s"><span class="pl-pds">&#39;</span>4<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>4<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L447">447</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC447">      <span class="pl-s"><span class="pl-pds">&#39;</span>5<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L448">448</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC448">      <span class="pl-s"><span class="pl-pds">&#39;</span>6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>6<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L449">449</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC449">      <span class="pl-s"><span class="pl-pds">&#39;</span>7<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>7<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L450">450</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC450">      <span class="pl-s"><span class="pl-pds">&#39;</span>8<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>8<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L451">451</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC451">      <span class="pl-s"><span class="pl-pds">&#39;</span>9<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>9<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L452">452</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC452">      <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L453">453</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC453">      <span class="pl-s"><span class="pl-pds">&#39;</span>11<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>11<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L454">454</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC454">      <span class="pl-s"><span class="pl-pds">&#39;</span>12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>12<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L455">455</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC455">      <span class="pl-s"><span class="pl-pds">&#39;</span>13<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>13<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L456">456</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC456">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L457">457</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC457">    gridColumnEnd<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="5">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/2babe0cb23d9f0029bce928fb9b8fb5992785681/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/2babe0cb23d9f0029bce928fb9b8fb5992785681">Add none/auto values for grid utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="5"><time-ago datetime="2019-12-30T12:47:45Z" class="no-wrap">Dec 30, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/505d03811ce784b7f47175cec7f7499df86cfe32/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L458">458</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC458">      auto<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>auto<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6">Add CSS grid utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-24T17:58:27Z" class="no-wrap">Dec 24, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/009f52d07fbf8fdaa10a54c3e118848ecc212a83/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L459">459</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC459">      <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L460">460</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC460">      <span class="pl-s"><span class="pl-pds">&#39;</span>2<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>2<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L461">461</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC461">      <span class="pl-s"><span class="pl-pds">&#39;</span>3<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>3<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L462">462</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC462">      <span class="pl-s"><span class="pl-pds">&#39;</span>4<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>4<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L463">463</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC463">      <span class="pl-s"><span class="pl-pds">&#39;</span>5<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L464">464</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC464">      <span class="pl-s"><span class="pl-pds">&#39;</span>6<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>6<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L465">465</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC465">      <span class="pl-s"><span class="pl-pds">&#39;</span>7<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>7<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L466">466</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC466">      <span class="pl-s"><span class="pl-pds">&#39;</span>8<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>8<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L467">467</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC467">      <span class="pl-s"><span class="pl-pds">&#39;</span>9<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>9<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L468">468</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC468">      <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L469">469</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC469">      <span class="pl-s"><span class="pl-pds">&#39;</span>11<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>11<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L470">470</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC470">      <span class="pl-s"><span class="pl-pds">&#39;</span>12<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>12<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L471">471</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC471">      <span class="pl-s"><span class="pl-pds">&#39;</span>13<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>13<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L472">472</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC472">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L473">473</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC473">    gridTemplateRows<span class="pl-k">:</span> {},</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L474">474</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC474">    gridRow<span class="pl-k">:</span> {},</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L475">475</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC475">    gridRowStart<span class="pl-k">:</span> {},</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L476">476</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC476">    gridRowEnd<span class="pl-k">:</span> {},</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7">Add first pass of transform utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-22T20:25:34Z" class="no-wrap">Dec 22, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/ecd1d102643e1c259d00b4f392bbdc71a86d8615/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L477">477</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC477">    transformOrigin<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L478">478</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC478">      center<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>center<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L479">479</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC479">      top<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>top<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L480">480</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC480">      <span class="pl-s"><span class="pl-pds">&#39;</span>top-right<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>top right<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L481">481</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC481">      right<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>right<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L482">482</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC482">      <span class="pl-s"><span class="pl-pds">&#39;</span>bottom-right<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>bottom right<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L483">483</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC483">      bottom<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>bottom<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L484">484</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC484">      <span class="pl-s"><span class="pl-pds">&#39;</span>bottom-left<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>bottom left<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L485">485</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC485">      left<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>left<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L486">486</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC486">      <span class="pl-s"><span class="pl-pds">&#39;</span>top-left<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>top left<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L487">487</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC487">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L488">488</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC488">    scale<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L489">489</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC489">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L490">490</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC490">      <span class="pl-s"><span class="pl-pds">&#39;</span>50<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>.5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/02ed29e3e97d1f85f1c85fd080a5073aa0ce59d5/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/02ed29e3e97d1f85f1c85fd080a5073aa0ce59d5">Simplify scales for scale and rotate</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-23T19:14:04Z" class="no-wrap">Dec 23, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/5335df2b2c89beedf88862b60173d885b6df9dc7/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L491">491</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC491">      <span class="pl-s"><span class="pl-pds">&#39;</span>75<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>.75<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7">Add first pass of transform utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-22T20:25:34Z" class="no-wrap">Dec 22, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/ecd1d102643e1c259d00b4f392bbdc71a86d8615/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L492">492</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC492">      <span class="pl-s"><span class="pl-pds">&#39;</span>90<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>.9<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/02ed29e3e97d1f85f1c85fd080a5073aa0ce59d5/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/02ed29e3e97d1f85f1c85fd080a5073aa0ce59d5">Simplify scales for scale and rotate</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-23T19:14:04Z" class="no-wrap">Dec 23, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/5335df2b2c89beedf88862b60173d885b6df9dc7/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L493">493</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC493">      <span class="pl-s"><span class="pl-pds">&#39;</span>95<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>.95<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7">Add first pass of transform utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-22T20:25:34Z" class="no-wrap">Dec 22, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/ecd1d102643e1c259d00b4f392bbdc71a86d8615/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L494">494</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC494">      <span class="pl-s"><span class="pl-pds">&#39;</span>100<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/02ed29e3e97d1f85f1c85fd080a5073aa0ce59d5/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/02ed29e3e97d1f85f1c85fd080a5073aa0ce59d5">Simplify scales for scale and rotate</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-23T19:14:04Z" class="no-wrap">Dec 23, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/5335df2b2c89beedf88862b60173d885b6df9dc7/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L495">495</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC495">      <span class="pl-s"><span class="pl-pds">&#39;</span>105<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.05<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7">Add first pass of transform utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-22T20:25:34Z" class="no-wrap">Dec 22, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/ecd1d102643e1c259d00b4f392bbdc71a86d8615/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L496">496</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC496">      <span class="pl-s"><span class="pl-pds">&#39;</span>110<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.1<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/02ed29e3e97d1f85f1c85fd080a5073aa0ce59d5/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/02ed29e3e97d1f85f1c85fd080a5073aa0ce59d5">Simplify scales for scale and rotate</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-23T19:14:04Z" class="no-wrap">Dec 23, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/5335df2b2c89beedf88862b60173d885b6df9dc7/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L497">497</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC497">      <span class="pl-s"><span class="pl-pds">&#39;</span>125<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.25<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7">Add first pass of transform utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-22T20:25:34Z" class="no-wrap">Dec 22, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/ecd1d102643e1c259d00b4f392bbdc71a86d8615/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L498">498</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC498">      <span class="pl-s"><span class="pl-pds">&#39;</span>150<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>1.5<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L499">499</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC499">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L500">500</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC500">    rotate<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/02ed29e3e97d1f85f1c85fd080a5073aa0ce59d5/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/02ed29e3e97d1f85f1c85fd080a5073aa0ce59d5">Simplify scales for scale and rotate</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-23T19:14:04Z" class="no-wrap">Dec 23, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/5335df2b2c89beedf88862b60173d885b6df9dc7/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L501">501</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC501">      <span class="pl-s"><span class="pl-pds">&#39;</span>-180<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>-180deg<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L502">502</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC502">      <span class="pl-s"><span class="pl-pds">&#39;</span>-90<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>-90deg<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L503">503</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC503">      <span class="pl-s"><span class="pl-pds">&#39;</span>-45<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>-45deg<span class="pl-pds">&#39;</span></span>,</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7">Add first pass of transform utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-22T20:25:34Z" class="no-wrap">Dec 22, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/ecd1d102643e1c259d00b4f392bbdc71a86d8615/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L504">504</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC504">      <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>0<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L505">505</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC505">      <span class="pl-s"><span class="pl-pds">&#39;</span>45<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>45deg<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L506">506</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC506">      <span class="pl-s"><span class="pl-pds">&#39;</span>90<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>90deg<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L507">507</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC507">      <span class="pl-s"><span class="pl-pds">&#39;</span>180<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>180deg<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L508">508</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC508">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/9fbbaff4003fd226f4f7b2821a25b23677824a6b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/9fbbaff4003fd226f4f7b2821a25b23677824a6b">Add negative translate and percentage translate values</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-24T00:22:33Z" class="no-wrap">Dec 24, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/e7c08c48e595db68a95fd95fb482e8f3f6f974c0/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L509">509</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC509">    <span class="pl-en">translate</span><span class="pl-k">:</span> (<span class="pl-smi">theme</span>, { negative }) <span class="pl-k">=&gt;</span> ({</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L510">510</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC510">      <span class="pl-k">...</span><span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>spacing<span class="pl-pds">&#39;</span></span>),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L511">511</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC511">      <span class="pl-k">...</span><span class="pl-en">negative</span>(<span class="pl-en">theme</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>spacing<span class="pl-pds">&#39;</span></span>)),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L512">512</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC512">      <span class="pl-s"><span class="pl-pds">&#39;</span>-full<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>-100%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L513">513</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC513">      <span class="pl-s"><span class="pl-pds">&#39;</span>-1/2<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>-50%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L514">514</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC514">      <span class="pl-s"><span class="pl-pds">&#39;</span>1/2<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>50%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L515">515</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC515">      full<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>100%<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L516">516</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC516">    }),</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L517">517</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC517">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L518">518</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC518">  variants<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="8">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/9b94cc1ed2e48be669e875e1074d12669efa1cc8/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/9b94cc1ed2e48be669e875e1074d12669efa1cc8">Add sr-only and not-sr-only utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="8"><time-ago datetime="2019-06-10T23:39:25Z" class="no-wrap">Jun 10, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9169e96075e8dcc575b210da7e50ec740a8bfd91/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L519">519</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC519">    accessibility<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b">Sort the variants in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T11:48:32Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4f3c6b4dcddea7731bec3b278987f6560cd482f2/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L520">520</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC520">    alignContent<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L521">521</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC521">    alignItems<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L522">522</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC522">    alignSelf<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L523">523</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC523">    appearance<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L524">524</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC524">    backgroundAttachment<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L525">525</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC525">    backgroundColor<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>hover<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L526">526</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC526">    backgroundPosition<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L527">527</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC527">    backgroundRepeat<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L528">528</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC528">    backgroundSize<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/b5355d2756d27d0e577a77a421f260a22722cf6a/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/b5355d2756d27d0e577a77a421f260a22722cf6a">Make everything responsive by default</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-08T15:51:04Z" class="no-wrap">May 8, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/a77d7778f2e46b8bb7e3478548279490c08ba61f/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L529">529</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC529">    borderCollapse<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L530">530</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC530">    borderColor<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>hover<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L531">531</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC531">    borderRadius<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L532">532</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC532">    borderStyle<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L533">533</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC533">    borderWidth<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b">Sort the variants in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T11:48:32Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4f3c6b4dcddea7731bec3b278987f6560cd482f2/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L534">534</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC534">    boxShadow<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>hover<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L535">535</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC535">    cursor<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L536">536</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC536">    display<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b">Sort the variants in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T11:48:32Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4f3c6b4dcddea7731bec3b278987f6560cd482f2/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L537">537</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC537">    fill<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L538">538</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC538">    flex<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b">Sort the variants in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T11:48:32Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4f3c6b4dcddea7731bec3b278987f6560cd482f2/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L539">539</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC539">    flexDirection<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L540">540</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC540">    flexGrow<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L541">541</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC541">    flexShrink<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b">Sort the variants in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T11:48:32Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4f3c6b4dcddea7731bec3b278987f6560cd482f2/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L542">542</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC542">    flexWrap<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L543">543</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC543">    float<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L544">544</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC544">    fontFamily<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b">Sort the variants in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T11:48:32Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4f3c6b4dcddea7731bec3b278987f6560cd482f2/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L545">545</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC545">    fontSize<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L546">546</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC546">    fontSmoothing<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L547">547</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC547">    fontStyle<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L548">548</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC548">    fontWeight<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>hover<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L549">549</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC549">    height<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b">Sort the variants in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T11:48:32Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4f3c6b4dcddea7731bec3b278987f6560cd482f2/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L550">550</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC550">    inset<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L551">551</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC551">    justifyContent<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L552">552</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC552">    letterSpacing<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L553">553</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC553">    lineHeight<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84">Added a file that was removed during merge</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9e4f54a17f18b784a0d446b5c60ea5c9c8c34b3d/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L554">554</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC554">    listStylePosition<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L555">555</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC555">    listStyleType<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L556">556</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC556">    margin<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L557">557</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC557">    maxHeight<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L558">558</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC558">    maxWidth<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L559">559</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC559">    minHeight<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L560">560</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC560">    minWidth<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L561">561</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC561">    objectFit<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L562">562</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC562">    objectPosition<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="8">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/91d969f7aa4ade282ffb6fb6a164d4c16ef4119d/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/91d969f7aa4ade282ffb6fb6a164d4c16ef4119d">Enable hover and focus variants for opacity by default</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="8"><time-ago datetime="2019-08-06T15:19:42Z" class="no-wrap">Aug 6, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4c0fb9162de02f1ee1f2f0b0eb9fbb5fa11b2b39/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L563">563</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC563">    opacity<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>hover<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b">Sort the variants in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T11:48:32Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4f3c6b4dcddea7731bec3b278987f6560cd482f2/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L564">564</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC564">    order<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/b5355d2756d27d0e577a77a421f260a22722cf6a/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/b5355d2756d27d0e577a77a421f260a22722cf6a">Make everything responsive by default</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-08T15:51:04Z" class="no-wrap">May 8, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/a77d7778f2e46b8bb7e3478548279490c08ba61f/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L565">565</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC565">    outline<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L566">566</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC566">    overflow<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L567">567</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC567">    padding<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="8">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/941aa9b429e88fb5bda5fe8cac15719c7697238f/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/941aa9b429e88fb5bda5fe8cac15719c7697238f">Add default variants for placeholder color utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="8"><time-ago datetime="2019-08-06T14:09:42Z" class="no-wrap">Aug 6, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/d2d081cba133736343d4d4d14c14fde712304de0/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L568">568</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC568">    placeholderColor<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L569">569</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC569">    pointerEvents<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L570">570</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC570">    position<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L571">571</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC571">    resize<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/b5355d2756d27d0e577a77a421f260a22722cf6a/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/b5355d2756d27d0e577a77a421f260a22722cf6a">Make everything responsive by default</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-08T15:51:04Z" class="no-wrap">May 8, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/a77d7778f2e46b8bb7e3478548279490c08ba61f/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L572">572</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC572">    stroke<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L573">573</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC573">    tableLayout<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L574">574</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC574">    textAlign<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L575">575</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC575">    textColor<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>hover<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L576">576</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC576">    textDecoration<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>hover<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b">Sort the variants in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T11:48:32Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4f3c6b4dcddea7731bec3b278987f6560cd482f2/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L577">577</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC577">    textTransform<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L578">578</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC578">    userSelect<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L579">579</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC579">    verticalAlign<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L580">580</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC580">    visibility<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L581">581</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC581">    whitespace<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L582">582</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC582">    width<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="mvdnbrk">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/mvdnbrk/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/mvdnbrk">
          <img height="20" width="20" alt="@mvdnbrk" src="https://avatars3.githubusercontent.com/u/802681?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/c92b71930728a0c404842f2b1e3f86983d6f9a9b">Sort the variants in alphabetical order.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-05-14T11:48:32Z" class="no-wrap">May 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/4f3c6b4dcddea7731bec3b278987f6560cd482f2/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L583">583</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC583">    wordBreak<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L584">584</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC584">    zIndex<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="5">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/d33fbc489560ce7f9ed8c0b8b205d2e4b882af73/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/d33fbc489560ce7f9ed8c0b8b205d2e4b882af73">Rename gap plugins to remove grid prefix, manually include old proper…</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="5"><time-ago datetime="2019-12-25T18:16:04Z" class="no-wrap">Dec 25, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/d075773c67f5922d824a21e23d89455319365bd0/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L585">585</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC585">    gap<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L586">586</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC586">    columnGap<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L587">587</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC587">    rowGap<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/d882d8d4fc5ee196ccfa51a08b4fff897f6258a6">Add CSS grid utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-24T17:58:27Z" class="no-wrap">Dec 24, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/009f52d07fbf8fdaa10a54c3e118848ecc212a83/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L588">588</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC588">    gridTemplateColumns<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L589">589</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC589">    gridColumn<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L590">590</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC590">    gridColumnStart<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L591">591</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC591">    gridColumnEnd<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L592">592</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC592">    gridTemplateRows<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L593">593</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC593">    gridRow<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L594">594</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC594">    gridRowStart<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L595">595</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC595">    gridRowEnd<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="6">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/5335df2b2c89beedf88862b60173d885b6df9dc7">Add first pass of transform utilities</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="6"><time-ago datetime="2019-12-22T20:25:34Z" class="no-wrap">Dec 22, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/ecd1d102643e1c259d00b4f392bbdc71a86d8615/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L596">596</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC596">    transform<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L597">597</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC597">    transformOrigin<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L598">598</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC598">    scale<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>hover<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L599">599</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC599">    rotate<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>hover<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L600">600</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC600">    translate<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>responsive<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>hover<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>focus<span class="pl-pds">&#39;</span></span>],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L601">601</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC601">  },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84">Added a file that was removed during merge</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/tailwindcss/tailwindcss/blame/9e4f54a17f18b784a0d446b5c60ea5c9c8c34b3d/stubs/defaultConfig.stub.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L602">602</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC602">  corePlugins<span class="pl-k">:</span> {},</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L603">603</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC603">  plugins<span class="pl-k">:</span> [],</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="9">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a class="message f6 text-gray-dark" data-hovercard-type="commit" data-hovercard-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/hovercard" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199">Updated CLI init commend</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="9"><time-ago datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L604">604</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC604">}</div>
                </div>
            </div>
          </div>
      </div>
    </div>

  </div>



  </div>
</div>

    </main>
  </div>
  

  </div>

        
<div class="footer container-lg width-full px-3" role="contentinfo">
  <div class="position-relative d-flex flex-justify-between pt-6 pb-2 mt-6 f6 text-gray border-top border-gray-light ">
    <ul class="list-style-none d-flex flex-wrap ">
      <li class="mr-3">&copy; 2020 GitHub, Inc.</li>
        <li class="mr-3"><a data-ga-click="Footer, go to terms, text:terms" href="https://github.com/site/terms">Terms</a></li>
        <li class="mr-3"><a data-ga-click="Footer, go to privacy, text:privacy" href="https://github.com/site/privacy">Privacy</a></li>
        <li class="mr-3"><a data-ga-click="Footer, go to security, text:security" href="https://github.com/security">Security</a></li>
        <li class="mr-3"><a href="https://githubstatus.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
        <li><a data-ga-click="Footer, go to help, text:help" href="https://help.github.com">Help</a></li>
    </ul>

    <a aria-label="Homepage" title="GitHub" class="footer-octicon d-none d-lg-block mx-lg-4" href="https://github.com">
      <svg height="24" class="octicon octicon-mark-github" viewBox="0 0 16 16" version="1.1" width="24" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg>
</a>
   <ul class="list-style-none d-flex flex-wrap ">
        <li class="mr-3"><a data-ga-click="Footer, go to contact, text:contact" href="https://github.com/contact">Contact GitHub</a></li>
        <li class="mr-3"><a href="https://github.com/pricing" data-ga-click="Footer, go to Pricing, text:Pricing">Pricing</a></li>
      <li class="mr-3"><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li class="mr-3"><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
        <li class="mr-3"><a href="https://github.blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a data-ga-click="Footer, go to about, text:about" href="https://github.com/about">About</a></li>

    </ul>
  </div>
  <div class="d-flex flex-justify-center pb-6">
    <span class="f6 text-gray-light"></span>
  </div>
</div>



  <div id="ajax-error-message" class="ajax-error-message flash flash-error">
    <svg class="octicon octicon-alert" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.893 1.5c-.183-.31-.52-.5-.887-.5s-.703.19-.886.5L.138 13.499a.98.98 0 000 1.001c.193.31.53.501.886.501h13.964c.367 0 .704-.19.877-.5a1.03 1.03 0 00.01-1.002L8.893 1.5zm.133 11.497H6.987v-2.003h2.039v2.003zm0-3.004H6.987V5.987h2.039v4.006z"/></svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
    </button>
    You can’t perform that action at this time.
  </div>


    <script crossorigin="anonymous" async="async" integrity="sha512-VTkKwyyXYz1e8w0v/7LXDKSa7yMy1qEQofgf/5bGrUv8wpbpaZxx5S3Uc6oYrvbOe432HJdJG5qsFdM9sbP+wg==" type="application/javascript" id="js-conditional-compat" data-src="https://github.githubassets.com/assets/compat-bootstrap-55390ac3.js"></script>
    <script crossorigin="anonymous" integrity="sha512-cxP+KR1XSSh29AL463dzUAHBchhXeGFmau39mDoF/w4eoAdNHqqynVYGNL8bMC65SDQYbQeDpk71eMKadQhObQ==" type="application/javascript" src="https://github.githubassets.com/assets/frameworks-7313fe29.js"></script>
    
    <script crossorigin="anonymous" async="async" integrity="sha512-pQP8Cv0kHJnTpys259V7ucuuxw2JdOaW2+7bUevII7Fv/iH8Pg7e+VEQtsf2BPCPq6cgJ955C1iQ7C+ziBcFyQ==" type="application/javascript" src="https://github.githubassets.com/assets/github-bootstrap-a503fc0a.js"></script>
    
    
    
  <div class="js-stale-session-flash flash flash-warn flash-banner" hidden
    >
    <svg class="octicon octicon-alert" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.893 1.5c-.183-.31-.52-.5-.887-.5s-.703.19-.886.5L.138 13.499a.98.98 0 000 1.001c.193.31.53.501.886.501h13.964c.367 0 .704-.19.877-.5a1.03 1.03 0 00.01-1.002L8.893 1.5zm.133 11.497H6.987v-2.003h2.039v2.003zm0-3.004H6.987V5.987h2.039v4.006z"/></svg>
    <span class="js-stale-session-flash-signed-in" hidden>You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="js-stale-session-flash-signed-out" hidden>You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
  <template id="site-details-dialog">
  <details class="details-reset details-overlay details-overlay-dark lh-default text-gray-dark hx_rsm" open>
    <summary role="button" aria-label="Close dialog"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast hx_rsm-dialog hx_rsm-modal">
      <button class="Box-btn-octicon m-0 btn-octicon position-absolute right-0 top-0" type="button" aria-label="Close dialog" data-close-dialog>
        <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
      </button>
      <div class="octocat-spinner my-6 js-details-dialog-spinner"></div>
    </details-dialog>
  </details>
</template>

  <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box box-shadow-large" style="width:360px;">
  </div>
</div>

  <div aria-live="polite" class="js-global-screen-reader-notice sr-only"></div>

  </body>
</html>

