





<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://github.githubassets.com">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <link crossorigin="anonymous" media="all" integrity="sha512-ZUjVod2EvYMDbGqRSyW0rpfgBq3i+gnR/4PfrzLsy5f20oIcRfgFQFVKgi3Ztp917bP1K/kdP5q8+nAlJ3+cFA==" rel="stylesheet" href="https://github.githubassets.com/assets/frameworks-6548d5a1dd84bd83036c6a914b25b4ae.css" />
  <link crossorigin="anonymous" media="all" integrity="sha512-HNV7VuXI98SSFimaE7r8eVsgrmzC37AMNXw1GrNbOl4wN3ATov+SdHusRTAAf4NPoRsUcOOQyYsOCA0AcN4m0w==" rel="stylesheet" href="https://github.githubassets.com/assets/site-1cd57b56e5c8f7c49216299a13bafc79.css" />
    <link crossorigin="anonymous" media="all" integrity="sha512-aX4OkLpzulpadvOncEEPpJZnQyeKNm2npzJowbL5JxptkoZXNPPy61R059xmEa3YyVF4Y4YXB6g+5o08uvdWpA==" rel="stylesheet" href="https://github.githubassets.com/assets/github-697e0e90ba73ba5a5a76f3a770410fa4.css" />
    
    
    
    


  <meta name="viewport" content="width=device-width">
  
  <title>History for stubs/defaultConfig.stub.js - tailwindcss/tailwindcss · GitHub</title>
    <meta name="description" content="A utility-first CSS framework for rapid UI development. - tailwindcss/tailwindcss">
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">

    <meta name="twitter:image:src" content="https://repository-images.githubusercontent.com/106017343/67c23f00-9462-11e9-9dba-c3970f6c612b" /><meta name="twitter:site" content="@github" /><meta name="twitter:card" content="summary_large_image" /><meta name="twitter:title" content="tailwindcss/tailwindcss" /><meta name="twitter:description" content="A utility-first CSS framework for rapid UI development. - tailwindcss/tailwindcss" />
    <meta property="og:image" content="https://repository-images.githubusercontent.com/106017343/67c23f00-9462-11e9-9dba-c3970f6c612b" /><meta property="og:site_name" content="GitHub" /><meta property="og:type" content="object" /><meta property="og:title" content="tailwindcss/tailwindcss" /><meta property="og:url" content="https://github.com/tailwindcss/tailwindcss" /><meta property="og:description" content="A utility-first CSS framework for rapid UI development. - tailwindcss/tailwindcss" />

  <link rel="assets" href="https://github.githubassets.com/">
  
  

  <meta name="request-id" content="3617:1021:27C7:3A3E:5E53B6F7" data-pjax-transient="true"/><meta name="html-safe-nonce" content="bf3511025571ac5a2676e45dbdba7a105de6202e" data-pjax-transient="true"/><meta name="visitor-payload" content="eyJyZWZlcnJlciI6Imh0dHA6Ly9naXRodWIuY29tL3RhaWx3aW5kY3NzL3RhaWx3aW5kY3NzL2NvbW1pdHMvbWFzdGVyP2FmdGVyPTI1NDI1MmFjOGViMmNlMGZiYTY5NDA5NjY0YzVlYjIxMmQ2YjA3ZTYrMzRcdTAwMjZwYXRoJTVCJTVEPXN0dWJzXHUwMDI2cGF0aCU1QiU1RD1kZWZhdWx0Q29uZmlnLnN0dWIuanMiLCJyZXF1ZXN0X2lkIjoiMzYxNzoxMDIxOjI3Qzc6M0EzRTo1RTUzQjZGNyIsInZpc2l0b3JfaWQiOiI4NDA1MzM0Mjk2NDUwMjgyOTQ2IiwicmVnaW9uX2VkZ2UiOiJzYS1lYXN0LTEiLCJyZWdpb25fcmVuZGVyIjoic2EtZWFzdC0xIn0=" data-pjax-transient="true"/><meta name="visitor-hmac" content="94bfffdc49f6723f8e81a724e7416c992b89b2d12f3af224e59f2e462a1c2854" data-pjax-transient="true"/>



  <meta name="github-keyboard-shortcuts" content="repository,commit-list" data-pjax-transient="true" />

  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

      <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
    <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
    <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">

  <meta name="octolytics-host" content="collector.githubapp.com" /><meta name="octolytics-app-id" content="github" /><meta name="octolytics-event-url" content="https://collector.githubapp.com/github-external/browser_event" /><meta name="octolytics-dimension-ga_id" content="" class="js-octo-ga-id" />
<meta name="analytics-location" content="/&lt;user-name&gt;/&lt;repo-name&gt;/commits/show" data-pjax-transient="true" />



    <meta name="google-analytics" content="UA-3769691-2">


<meta class="js-ga-set" name="dimension1" content="Logged Out">



  

      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

      <meta name="expected-hostname" content="github.com">


    <meta name="enabled-features" content="MARKETPLACE_FEATURED_BLOG_POSTS,MARKETPLACE_INVOICED_BILLING,MARKETPLACE_SOCIAL_PROOF_CUSTOMERS,MARKETPLACE_TRENDING_SOCIAL_PROOF,MARKETPLACE_RECOMMENDATIONS,MARKETPLACE_PENDING_INSTALLATIONS,RELATED_ISSUES">

  <meta http-equiv="x-pjax-version" content="29999ca8cf0c8ddf469b9759ce08131a">
  

      <link href="https://github.com/tailwindcss/tailwindcss/commits/master.atom" rel="alternate" title="Recent Commits to tailwindcss:master" type="application/atom+xml">

  <meta name="go-import" content="github.com/tailwindcss/tailwindcss git https://github.com/tailwindcss/tailwindcss.git">

  <meta name="octolytics-dimension-user_id" content="30317862" /><meta name="octolytics-dimension-user_login" content="tailwindcss" /><meta name="octolytics-dimension-repository_id" content="106017343" /><meta name="octolytics-dimension-repository_nwo" content="tailwindcss/tailwindcss" /><meta name="octolytics-dimension-repository_public" content="true" /><meta name="octolytics-dimension-repository_is_fork" content="false" /><meta name="octolytics-dimension-repository_network_root_id" content="106017343" /><meta name="octolytics-dimension-repository_network_root_nwo" content="tailwindcss/tailwindcss" /><meta name="octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" content="false" />




  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://github.githubassets.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" class="js-site-favicon" href="https://github.githubassets.com/favicon.ico">

<meta name="theme-color" content="#1e2327">


  <link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-out env-production min-width-lg">
    

  <div class="position-relative js-header-wrapper ">
    <a href="#start-of-content" tabindex="1" class="px-2 py-4 bg-blue text-white show-on-focus js-skip-to-content">Skip to content</a>
    <span class="Progress progress-pjax-loader position-fixed width-full js-pjax-loader-bar">
      <span class="progress-pjax-loader-bar top-0 left-0" style="width: 0%;"></span>
    </span>

    
    



        <header class="Header-old header-logged-out  position-relative f4 py-2" role="banner">
  <div class="container-lg d-flex px-3">
    <div class="d-flex flex-justify-between flex-items-center">
        <a class="mr-4" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
          <svg height="32" class="octicon octicon-mark-github text-white" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg>
        </a>
    </div>

    <div class="HeaderMenu HeaderMenu--logged-out d-flex flex-justify-between flex-items-center flex-auto">
      <div class="d-none">
        <button class="btn-link js-details-target" type="button" aria-label="Toggle navigation" aria-expanded="false">
          <svg height="24" class="octicon octicon-x text-gray" viewBox="0 0 12 16" version="1.1" width="18" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
        </button>
      </div>

        <nav class="mt-0" aria-label="Global">
          <ul class="d-flex list-style-none">
              <li class=" mr-3 mr-lg-3 edge-item-fix position-relative flex-wrap flex-justify-between d-flex flex-items-center ">
                <details class="HeaderMenu-details details-overlay details-reset width-full">
                  <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap  d-inline-block">
                    Why GitHub?
                    <svg x="0px" y="0px" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-relative">
                      <path d="M1,1l6.2,6L13,1"></path>
                    </svg>
                  </summary>
                  <div class="dropdown-menu flex-auto rounded-1 bg-white px-0 mt-0  p-4 left-n4 position-absolute">
                    <a href="/features" class="py-2 lh-condensed-ultra d-block link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Features">Features <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a>
                    <ul class="list-style-none f5 pb-3">
                      <li class="edge-item-fix"><a href="/features/code-review/" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Code review">Code review</a></li>
                      <li class="edge-item-fix"><a href="/features/project-management/" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Project management">Project management</a></li>
                      <li class="edge-item-fix"><a href="/features/integrations" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Integrations">Integrations</a></li>
                      <li class="edge-item-fix"><a href="/features/actions" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Actions">Actions</a></li>
                          <li class="edge-item-fix"><a href="/features/packages" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to GitHub Packages">Packages</a></li>
                      <li class="edge-item-fix"><a href="/features/security" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Security">Security</a></li>
                      <li class="edge-item-fix"><a href="/features#team-management" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Team management">Team management</a></li>
                      <li class="edge-item-fix"><a href="/features#hosting" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Code hosting">Hosting</a></li>
                    </ul>

                    <ul class="list-style-none mb-0 border-lg-top pt-lg-3">
                      <li class="edge-item-fix"><a href="/customer-stories" class="py-2 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Customer stories">Customer stories <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                      <li class="edge-item-fix"><a href="/security" class="py-2 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Security">Security <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                    </ul>
                  </div>
                </details>
              </li>
              <li class=" mr-3 mr-lg-3">
                <a href="/enterprise" class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-ga-click="(Logged out) Header, go to Enterprise">Enterprise</a>
              </li>

              <li class=" mr-3 mr-lg-3 edge-item-fix position-relative flex-wrap flex-justify-between d-flex flex-items-center ">
                <details class="HeaderMenu-details details-overlay details-reset width-full">
                  <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap  d-inline-block">
                    Explore
                    <svg x="0px" y="0px" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-relative">
                      <path d="M1,1l6.2,6L13,1"></path>
                    </svg>
                  </summary>

                  <div class="dropdown-menu flex-auto rounded-1 bg-white px-0 pt-2 pb-0 mt-0  p-4 left-n4 position-absolute">
                    <ul class="list-style-none mb-3">
                      <li class="edge-item-fix"><a href="/explore" class="py-2 lh-condensed-ultra d-block link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Explore">Explore GitHub <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                    </ul>

                    <h4 class="text-gray-light text-normal text-mono f5 mb-2  border-top pt-3">Learn &amp; contribute</h4>
                    <ul class="list-style-none mb-3">
                      <li class="edge-item-fix"><a href="/topics" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Topics">Topics</a></li>
                        <li class="edge-item-fix"><a href="/collections" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Collections">Collections</a></li>
                      <li class="edge-item-fix"><a href="/trending" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Trending">Trending</a></li>
                      <li class="edge-item-fix"><a href="https://lab.github.com/" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Learning lab">Learning Lab</a></li>
                      <li class="edge-item-fix"><a href="https://opensource.guide" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Open source guides">Open source guides</a></li>
                    </ul>

                    <h4 class="text-gray-light text-normal text-mono f5 mb-2  border-top pt-3">Connect with others</h4>
                    <ul class="list-style-none mb-0">
                      <li class="edge-item-fix"><a href="https://github.com/events" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Events">Events</a></li>
                      <li class="edge-item-fix"><a href="https://github.community" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Community forum">Community forum</a></li>
                      <li class="edge-item-fix"><a href="https://education.github.com" class="py-2 pb-0 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to GitHub Education">GitHub Education</a></li>
                    </ul>
                  </div>
                </details>
              </li>

              <li class=" mr-3 mr-lg-3">
                <a href="/marketplace" class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-ga-click="(Logged out) Header, go to Marketplace">Marketplace</a>
              </li>

              <li class=" mr-3 mr-lg-3 edge-item-fix position-relative flex-wrap flex-justify-between d-flex flex-items-center ">
                <details class="HeaderMenu-details details-overlay details-reset width-full">
                  <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap  d-inline-block">
                    Pricing
                    <svg x="0px" y="0px" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-relative">
                       <path d="M1,1l6.2,6L13,1"></path>
                    </svg>
                  </summary>

                  <div class="dropdown-menu flex-auto rounded-1 bg-white px-0 pt-2 pb-4 mt-0  p-4 left-n4 position-absolute">
                    <a href="/pricing" class="pb-2 lh-condensed-ultra d-block link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Pricing">Plans <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a>

                    <ul class="list-style-none mb-3">
                      <li class="edge-item-fix"><a href="/pricing#feature-comparison" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Compare plans">Compare plans</a></li>
                      <li class="edge-item-fix"><a href="https://enterprise.github.com/contact" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Contact Sales">Contact Sales</a></li>
                    </ul>

                    <ul class="list-style-none mb-0  border-top pt-3">
                      <li class="edge-item-fix"><a href="/nonprofit" class="py-2 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Nonprofits">Nonprofit <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                      <li class="edge-item-fix"><a href="https://education.github.com" class="py-2 pb-0 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover"  data-ga-click="(Logged out) Header, go to Education">Education <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                    </ul>
                  </div>
                </details>
              </li>
          </ul>
        </nav>

      <div class="d-flex flex-items-center px-0 text-center text-left">
          <div class="d-lg-flex ">
            <div class="header-search mr-3 scoped-search site-scoped-search js-site-search position-relative js-jump-to"
  role="combobox"
  aria-owns="jump-to-results"
  aria-label="Search or jump to"
  aria-haspopup="listbox"
  aria-expanded="false"
>
  <div class="position-relative">
    <!-- '"` --><!-- </textarea></xmp> --></option></form><form class="js-site-search-form" role="search" aria-label="Site" data-scope-type="Repository" data-scope-id="106017343" data-scoped-search-url="/tailwindcss/tailwindcss/search" data-unscoped-search-url="/search" action="/tailwindcss/tailwindcss/search" accept-charset="UTF-8" method="get"><input name="utf8" type="hidden" value="&#x2713;" />
      <label class="form-control input-sm header-search-wrapper p-0 header-search-wrapper-jump-to position-relative d-flex flex-justify-between flex-items-center js-chromeless-input-container">
        <input type="text"
          class="form-control input-sm header-search-input jump-to-field js-jump-to-field js-site-search-focus js-site-search-field is-clearable"
          data-hotkey="s,/"
          name="q"
          value=""
          placeholder="Search"
          data-unscoped-placeholder="Search GitHub"
          data-scoped-placeholder="Search"
          autocapitalize="off"
          aria-autocomplete="list"
          aria-controls="jump-to-results"
          aria-label="Search"
          data-jump-to-suggestions-path="/_graphql/GetSuggestedNavigationDestinations"
          spellcheck="false"
          autocomplete="off"
          >
          <input type="hidden" data-csrf="true" class="js-data-jump-to-suggestions-path-csrf" value="Lz3X7Sva5uCQRJvSLAO/Ean8yuMCb8nOmWlhf/u/BkpJ7+piDTTtiDp4Dxdc89e4f/Ovp7+i1Lj1CZWoC3cFTw==" />
          <input type="hidden" class="js-site-search-type-field" name="type" >
            <img src="https://github.githubassets.com/images/search-key-slash.svg" alt="" class="mr-2 header-search-key-slash">

            <div class="Box position-absolute overflow-hidden d-none jump-to-suggestions js-jump-to-suggestions-container">
              
<ul class="d-none js-jump-to-suggestions-template-container">
  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-suggestion" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg height="16" width="16" class="octicon octicon-repo flex-shrink-0 js-jump-to-octicon-repo d-none" title="Repository" aria-label="Repository" viewBox="0 0 12 16" version="1.1" role="img"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-project flex-shrink-0 js-jump-to-octicon-project d-none" title="Project" aria-label="Project" viewBox="0 0 15 16" version="1.1" role="img"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 00-1 1v14a1 1 0 001 1h13a1 1 0 001-1V1a1 1 0 00-1-1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-search flex-shrink-0 js-jump-to-octicon-search d-none" title="Search" aria-label="Search" viewBox="0 0 16 16" version="1.1" role="img"><path fill-rule="evenodd" d="M15.7 13.3l-3.81-3.83A5.93 5.93 0 0013 6c0-3.31-2.69-6-6-6S1 2.69 1 6s2.69 6 6 6c1.3 0 2.48-.41 3.47-1.11l3.83 3.81c.19.2.45.3.7.3.25 0 .52-.09.7-.3a.996.996 0 000-1.41v.01zM7 10.7c-2.59 0-4.7-2.11-4.7-4.7 0-2.59 2.11-4.7 4.7-4.7 2.59 0 4.7 2.11 4.7 4.7 0 2.59-2.11 4.7-4.7 4.7z"/></svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

</ul>

<ul class="d-none js-jump-to-no-results-template-container">
  <li class="d-flex flex-justify-center flex-items-center f5 d-none js-jump-to-suggestion p-2">
    <span class="text-gray">No suggested jump to results</span>
  </li>
</ul>

<ul id="jump-to-results" role="listbox" class="p-0 m-0 js-navigation-container jump-to-suggestions-results-container js-jump-to-suggestions-results-container">
  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-scoped-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg height="16" width="16" class="octicon octicon-repo flex-shrink-0 js-jump-to-octicon-repo d-none" title="Repository" aria-label="Repository" viewBox="0 0 12 16" version="1.1" role="img"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-project flex-shrink-0 js-jump-to-octicon-project d-none" title="Project" aria-label="Project" viewBox="0 0 15 16" version="1.1" role="img"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 00-1 1v14a1 1 0 001 1h13a1 1 0 001-1V1a1 1 0 00-1-1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-search flex-shrink-0 js-jump-to-octicon-search d-none" title="Search" aria-label="Search" viewBox="0 0 16 16" version="1.1" role="img"><path fill-rule="evenodd" d="M15.7 13.3l-3.81-3.83A5.93 5.93 0 0013 6c0-3.31-2.69-6-6-6S1 2.69 1 6s2.69 6 6 6c1.3 0 2.48-.41 3.47-1.11l3.83 3.81c.19.2.45.3.7.3.25 0 .52-.09.7-.3a.996.996 0 000-1.41v.01zM7 10.7c-2.59 0-4.7-2.11-4.7-4.7 0-2.59 2.11-4.7 4.7-4.7 2.59 0 4.7 2.11 4.7 4.7 0 2.59-2.11 4.7-4.7 4.7z"/></svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-global-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg height="16" width="16" class="octicon octicon-repo flex-shrink-0 js-jump-to-octicon-repo d-none" title="Repository" aria-label="Repository" viewBox="0 0 12 16" version="1.1" role="img"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-project flex-shrink-0 js-jump-to-octicon-project d-none" title="Project" aria-label="Project" viewBox="0 0 15 16" version="1.1" role="img"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 00-1 1v14a1 1 0 001 1h13a1 1 0 001-1V1a1 1 0 00-1-1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-search flex-shrink-0 js-jump-to-octicon-search d-none" title="Search" aria-label="Search" viewBox="0 0 16 16" version="1.1" role="img"><path fill-rule="evenodd" d="M15.7 13.3l-3.81-3.83A5.93 5.93 0 0013 6c0-3.31-2.69-6-6-6S1 2.69 1 6s2.69 6 6 6c1.3 0 2.48-.41 3.47-1.11l3.83 3.81c.19.2.45.3.7.3.25 0 .52-.09.7-.3a.996.996 0 000-1.41v.01zM7 10.7c-2.59 0-4.7-2.11-4.7-4.7 0-2.59 2.11-4.7 4.7-4.7 2.59 0 4.7 2.11 4.7 4.7 0 2.59-2.11 4.7-4.7 4.7z"/></svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>


</ul>

            </div>
      </label>
</form>  </div>
</div>

          </div>

        <a href="/login?return_to=%2Ftailwindcss%2Ftailwindcss%2Fcommits%2Fmaster%3Fafter%3D254252ac8eb2ce0fba69409664c5eb212d6b07e6%2B69%26path%255B%255D%3Dstubs%26path%255B%255D%3DdefaultConfig.stub.js"
          class="HeaderMenu-link no-underline mr-3"
          data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header menu&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/tailwindcss/tailwindcss/commits/master?after=254252ac8eb2ce0fba69409664c5eb212d6b07e6+69&amp;path%5B%5D=stubs&amp;path%5B%5D=defaultConfig.stub.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="4e2350799f9b1dbe3ed3124fb2173cf1513e6a00ae4af73424ca82ad14baa6dc"
          data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">
          Sign&nbsp;in
        </a>
          <a href="/join?source_repo=tailwindcss%2Ftailwindcss"
            class="HeaderMenu-link d-inline-block no-underline border border-gray-dark rounded-1 px-2 py-1"
            data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header menu&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/tailwindcss/tailwindcss/commits/master?after=254252ac8eb2ce0fba69409664c5eb212d6b07e6+69&amp;path%5B%5D=stubs&amp;path%5B%5D=defaultConfig.stub.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="4e2350799f9b1dbe3ed3124fb2173cf1513e6a00ae4af73424ca82ad14baa6dc"
            data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">
            Sign&nbsp;up
          </a>
      </div>
    </div>
  </div>
</header>

  </div>

  <div id="start-of-content" class="show-on-focus"></div>


    <div id="js-flash-container">

</div>


    






  <div class="application-main " data-commit-hovercards-enabled>
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode" class="">
    <main id="js-repo-pjax-container" data-pjax-container >
      
  




  









  <div class="pagehead repohead hx_repohead readability-menu bg-gray-light pb-0 pt-3">

    <div class="container-lg mb-4 px-3 d-flex">

      <div class="flex-auto min-width-0 width-fit mr-3">
        <h1 class="public  d-flex flex-wrap flex-items-center break-word float-none ">
    <svg class="octicon octicon-repo" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
  <span class="author ml-1 flex-self-stretch" itemprop="author">
    <a class="url fn" rel="author" data-hovercard-type="organization" data-hovercard-url="/orgs/tailwindcss/hovercard" href="/tailwindcss">tailwindcss</a>
  </span>
  <span class="path-divider flex-self-stretch">/</span>
  <strong itemprop="name" class="mr-2 flex-self-stretch">
    <a data-pjax="#js-repo-pjax-container" href="/tailwindcss/tailwindcss">tailwindcss</a>
  </strong>
  
</h1>


      </div>

      <ul class="pagehead-actions flex-shrink-0"  >




  <li>
    
  <a class="tooltipped tooltipped-s btn btn-sm btn-with-count" aria-label="You must be signed in to watch a repository" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;notification subscription menu watch&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/tailwindcss/tailwindcss/commits/master?after=254252ac8eb2ce0fba69409664c5eb212d6b07e6+69&amp;path%5B%5D=stubs&amp;path%5B%5D=defaultConfig.stub.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="82c57c637508cbccfbaa53b1a365ec52ab8c30e902e2842e010976aae7fa9ab1" href="/login?return_to=%2Ftailwindcss%2Ftailwindcss">
    <svg class="octicon octicon-eye v-align-text-bottom" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.06 2C3 2 0 8 0 8s3 6 8.06 6C13 14 16 8 16 8s-3-6-7.94-6zM8 12c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4zm2-4c0 1.11-.89 2-2 2-1.11 0-2-.89-2-2 0-1.11.89-2 2-2 1.11 0 2 .89 2 2z"/></svg>
    Watch
</a>    <a class="social-count" href="/tailwindcss/tailwindcss/watchers"
       aria-label="390 users are watching this repository">
      390
    </a>

  </li>

  <li>
        <a class="btn btn-sm btn-with-count tooltipped tooltipped-s" aria-label="You must be signed in to star a repository" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;star button&quot;,&quot;repository_id&quot;:106017343,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/tailwindcss/tailwindcss/commits/master?after=254252ac8eb2ce0fba69409664c5eb212d6b07e6+69&amp;path%5B%5D=stubs&amp;path%5B%5D=defaultConfig.stub.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="be7fad4eed5c4dd1df22b6e707caccd1a607ade5697f9ca21c5ebd8847fb79f1" href="/login?return_to=%2Ftailwindcss%2Ftailwindcss">
      <svg aria-label="star" height="16" class="octicon octicon-star v-align-text-bottom" viewBox="0 0 14 16" version="1.1" width="14" role="img"><path fill-rule="evenodd" d="M14 6l-4.9-.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14 7 11.67 11.33 14l-.93-4.74L14 6z"/></svg>

      Star
</a>
    <a class="social-count js-social-count" href="/tailwindcss/tailwindcss/stargazers"
      aria-label="19919 users starred this repository">
      19.9k
    </a>

  </li>

  <li>
      <a class="btn btn-sm btn-with-count tooltipped tooltipped-s" aria-label="You must be signed in to fork a repository" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;repo details fork button&quot;,&quot;repository_id&quot;:106017343,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/tailwindcss/tailwindcss/commits/master?after=254252ac8eb2ce0fba69409664c5eb212d6b07e6+69&amp;path%5B%5D=stubs&amp;path%5B%5D=defaultConfig.stub.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="18fe2a033d083827c8bc4cdc87867fd6fa42063c157edf818132b9ea9adb626c" href="/login?return_to=%2Ftailwindcss%2Ftailwindcss">
        <svg class="octicon octicon-repo-forked v-align-text-bottom" viewBox="0 0 10 16" version="1.1" width="10" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8 1a1.993 1.993 0 00-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 002 1a1.993 1.993 0 00-1 3.72V6.5l3 3v1.78A1.993 1.993 0 005 15a1.993 1.993 0 001-3.72V9.5l3-3V4.72A1.993 1.993 0 008 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
        Fork
</a>
    <a href="/tailwindcss/tailwindcss/network/members" class="social-count"
       aria-label="890 users forked this repository">
      890
    </a>
  </li>
</ul>

    </div>
      
<nav class="hx_reponav reponav js-repo-nav js-sidenav-container-pjax clearfix container-lg px-3"
     itemscope
     itemtype="http://schema.org/BreadcrumbList"
    aria-label="Repository"
     data-pjax="#js-repo-pjax-container">

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a class="js-selected-navigation-item selected reponav-item" itemprop="url" data-hotkey="g c" aria-current="page" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages /tailwindcss/tailwindcss" href="/tailwindcss/tailwindcss">
      <div class="d-inline"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></div>
      <span itemprop="name">Code</span>
      <meta itemprop="position" content="1">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
      <a itemprop="url" data-hotkey="g i" class="js-selected-navigation-item reponav-item" data-selected-links="repo_issues repo_labels repo_milestones /tailwindcss/tailwindcss/issues" href="/tailwindcss/tailwindcss/issues">
        <div class="d-inline"><svg class="octicon octicon-issue-opened" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 011.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z"/></svg></div>
        <span itemprop="name">Issues</span>
        <span class="Counter">50</span>
        <meta itemprop="position" content="2">
</a>    </span>


  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a data-hotkey="g p" data-skip-pjax="true" itemprop="url" class="js-selected-navigation-item reponav-item" data-selected-links="repo_pulls checks /tailwindcss/tailwindcss/pulls" href="/tailwindcss/tailwindcss/pulls">
      <div class="d-inline"><svg class="octicon octicon-git-pull-request" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0010 15a1.993 1.993 0 001-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 00-1 3.72v6.56A1.993 1.993 0 002 15a1.993 1.993 0 001-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg></div>
      <span itemprop="name">Pull requests</span>
      <span class="Counter">11</span>
      <meta itemprop="position" content="4">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement" class="position-relative float-left">
      <a data-hotkey="g w" data-skip-pjax="true" class="js-selected-navigation-item reponav-item" data-selected-links="repo_actions /tailwindcss/tailwindcss/actions" href="/tailwindcss/tailwindcss/actions">
        <div class="d-inline"><svg class="octicon octicon-play" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M14 8A7 7 0 110 8a7 7 0 0114 0zm-8.223 3.482l4.599-3.066a.5.5 0 000-.832L5.777 4.518A.5.5 0 005 4.934v6.132a.5.5 0 00.777.416z"/></svg></div>
        Actions
</a>
    </span>

    <a data-hotkey="g b" class="js-selected-navigation-item reponav-item" data-selected-links="repo_projects new_repo_project repo_project /tailwindcss/tailwindcss/projects" href="/tailwindcss/tailwindcss/projects">
      <div class="d-inline"><svg class="octicon octicon-project" viewBox="0 0 15 16" version="1.1" width="15" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 00-1 1v14a1 1 0 001 1h13a1 1 0 001-1V1a1 1 0 00-1-1z"/></svg></div>
      Projects
      <span class="Counter" >0</span>
</a>

    <a data-skip-pjax="true" class="js-selected-navigation-item reponav-item" data-selected-links="security alerts policy token_scanning code_scanning /tailwindcss/tailwindcss/security/advisories" href="/tailwindcss/tailwindcss/security/advisories">
      <div class="d-inline"><svg class="octicon octicon-shield" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M0 2l7-2 7 2v6.02C14 12.69 8.69 16 7 16c-1.69 0-7-3.31-7-7.98V2zm1 .75L7 1l6 1.75v5.268C13 12.104 8.449 15 7 15c-1.449 0-6-2.896-6-6.982V2.75zm1 .75L7 2v12c-1.207 0-5-2.482-5-5.985V3.5z"/></svg></div>
      Security
</a>
    <a class="js-selected-navigation-item reponav-item" data-selected-links="repo_graphs repo_contributors dependency_graph pulse people /tailwindcss/tailwindcss/pulse" href="/tailwindcss/tailwindcss/pulse">
      <div class="d-inline"><svg class="octicon octicon-graph" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M16 14v1H0V0h1v14h15zM5 13H3V8h2v5zm4 0H7V3h2v10zm4 0h-2V6h2v7z"/></svg></div>
      Insights
</a>

</nav>


  </div>


<div class="container-lg clearfix new-discussion-timeline  px-3">
  <div class="repository-content ">

    
    
    <div class="file-navigation">
      <div class="breadcrumb">
        History for <span class="js-repo-root text-bold"><span class="js-path-segment"><a data-pjax="true" href="/tailwindcss/tailwindcss/commits/master"><span>tailwindcss</span></a></span></span><span class="separator">/</span><span class="js-path-segment"><a data-pjax="true" href="/tailwindcss/tailwindcss/commits/master/stubs"><span>stubs</span></a></span><span class="separator">/</span><strong class="final-path">defaultConfig.stub.js</strong>
      </div>
    </div>

    <div class="commits-listing commits-listing-padded js-navigation-container js-active-navigation-container" data-navigation-scroll="page">
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 25, 2019
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item js-commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:106017343:commit:7544c1bbd2198b8df72b2c90d63b606e3e5e822b"
    data-url="/tailwindcss/tailwindcss/commit/7544c1bbd2198b8df72b2c90d63b606e3e5e822b/_render_node/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a aria-label="Drop SFMono from default mono font stack" class="message js-navigation-open" data-pjax="true" href="/tailwindcss/tailwindcss/commit/7544c1bbd2198b8df72b2c90d63b606e3e5e822b#diff-35dd1ebd14934754769c53d1ade148e2">Drop SFMono from default mono font stack</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/tailwindcss/tailwindcss/commits?author=adamwathan"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by adamwathan">adamwathan</a>


  committed
  <relative-time datetime="2019-03-25T17:16:11Z" class="no-wrap">Mar 25, 2019</relative-time>

    </div>
      <div class="commit-indicator">
        
  <details class="commit-build-statuses details-overlay details-reset js-dropdown-details"
    data-deferred-details-content-url="/_render_node/MDE3OlN0YXR1c0NoZWNrUm9sbHVwMTA2MDE3MzQzOjc1NDRjMWJiZDIxOThiOGRmNzJiMmM5MGQ2M2I2MDZlM2U1ZTgyMmI=/statuses/combined_branch_status">
    <summary class="text-green">
      <svg aria-label="1 / 1 checks OK" class="octicon octicon-check" viewBox="0 0 12 16" version="1.1" width="12" height="16" role="img"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
    </summary>
    <div class="dropdown-menu dropdown-menu-e overflow-hidden">
      <include-fragment class="m-4 d-flex flex-column flex-items-center">
        <div class="anim-pulse"><svg height="32" class="octicon octicon-octoface" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M14.7 5.34c.13-.32.55-1.59-.13-3.31 0 0-1.05-.33-3.44 1.3-1-.28-2.07-.32-3.13-.32s-2.13.04-3.13.32c-2.39-1.64-3.44-1.3-3.44-1.3-.68 1.72-.26 2.99-.13 3.31C.49 6.21 0 7.33 0 8.69 0 13.84 3.33 15 7.98 15S16 13.84 16 8.69c0-1.36-.49-2.48-1.3-3.35zM8 14.02c-3.3 0-5.98-.15-5.98-3.35 0-.76.38-1.48 1.02-2.07 1.07-.98 2.9-.46 4.96-.46 2.07 0 3.88-.52 4.96.46.65.59 1.02 1.3 1.02 2.07 0 3.19-2.68 3.35-5.98 3.35zM5.49 9.01c-.66 0-1.2.8-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.54-1.78-1.2-1.78zm5.02 0c-.66 0-1.2.79-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.53-1.78-1.2-1.78z"/></svg></div>
        <div class="text-gray no-wrap">Loading status checks&hellip;</div>
      </include-fragment>
    </div>
  </details>


      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy value="7544c1bbd2198b8df72b2c90d63b606e3e5e822b" aria-label="Copy the full SHA" class="btn btn-outline BtnGroup-item">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/tailwindcss/tailwindcss/commit/7544c1bbd2198b8df72b2c90d63b606e3e5e822b#diff-35dd1ebd14934754769c53d1ade148e2" class="sha btn btn-outline BtnGroup-item">
      7544c1b
    </a>
  </div>
  <a href="/tailwindcss/tailwindcss/tree/7544c1bbd2198b8df72b2c90d63b606e3e5e822b" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 20, 2019
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item js-commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:106017343:commit:76d6356a5849de7b221580c4d03f7de74ee77f23"
    data-url="/tailwindcss/tailwindcss/commit/76d6356a5849de7b221580c4d03f7de74ee77f23/_render_node/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a aria-label="Added container to defaultConfigStub" class="message js-navigation-open" data-pjax="true" href="/tailwindcss/tailwindcss/commit/76d6356a5849de7b221580c4d03f7de74ee77f23#diff-35dd1ebd14934754769c53d1ade148e2">Added container to defaultConfigStub</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/tailwindcss/tailwindcss/commits?author=MattStypa"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by MattStypa">MattStypa</a>


  committed
  <relative-time datetime="2019-03-20T12:46:16Z" class="no-wrap">Mar 20, 2019</relative-time>

    </div>
      <div class="commit-indicator">
        
  <details class="commit-build-statuses details-overlay details-reset js-dropdown-details"
    data-deferred-details-content-url="/_render_node/MDE3OlN0YXR1c0NoZWNrUm9sbHVwMTA2MDE3MzQzOjc2ZDYzNTZhNTg0OWRlN2IyMjE1ODBjNGQwM2Y3ZGU3NGVlNzdmMjM=/statuses/combined_branch_status">
    <summary class="text-green">
      <svg aria-label="1 / 1 checks OK" class="octicon octicon-check" viewBox="0 0 12 16" version="1.1" width="12" height="16" role="img"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
    </summary>
    <div class="dropdown-menu dropdown-menu-e overflow-hidden">
      <include-fragment class="m-4 d-flex flex-column flex-items-center">
        <div class="anim-pulse"><svg height="32" class="octicon octicon-octoface" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M14.7 5.34c.13-.32.55-1.59-.13-3.31 0 0-1.05-.33-3.44 1.3-1-.28-2.07-.32-3.13-.32s-2.13.04-3.13.32c-2.39-1.64-3.44-1.3-3.44-1.3-.68 1.72-.26 2.99-.13 3.31C.49 6.21 0 7.33 0 8.69 0 13.84 3.33 15 7.98 15S16 13.84 16 8.69c0-1.36-.49-2.48-1.3-3.35zM8 14.02c-3.3 0-5.98-.15-5.98-3.35 0-.76.38-1.48 1.02-2.07 1.07-.98 2.9-.46 4.96-.46 2.07 0 3.88-.52 4.96.46.65.59 1.02 1.3 1.02 2.07 0 3.19-2.68 3.35-5.98 3.35zM5.49 9.01c-.66 0-1.2.8-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.54-1.78-1.2-1.78zm5.02 0c-.66 0-1.2.79-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.53-1.78-1.2-1.78z"/></svg></div>
        <div class="text-gray no-wrap">Loading status checks&hellip;</div>
      </include-fragment>
    </div>
  </details>


      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy value="76d6356a5849de7b221580c4d03f7de74ee77f23" aria-label="Copy the full SHA" class="btn btn-outline BtnGroup-item">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/tailwindcss/tailwindcss/commit/76d6356a5849de7b221580c4d03f7de74ee77f23#diff-35dd1ebd14934754769c53d1ade148e2" class="sha btn btn-outline BtnGroup-item">
      76d6356
    </a>
  </div>
  <a href="/tailwindcss/tailwindcss/tree/76d6356a5849de7b221580c4d03f7de74ee77f23" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 18, 2019
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item js-commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:106017343:commit:9bf413933c7f1118a47e78d365e13b327e48f5a6"
    data-url="/tailwindcss/tailwindcss/commit/9bf413933c7f1118a47e78d365e13b327e48f5a6/_render_node/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a aria-label="Fix default border color." class="message js-navigation-open" data-pjax="true" href="/tailwindcss/tailwindcss/commit/9bf413933c7f1118a47e78d365e13b327e48f5a6#diff-35dd1ebd14934754769c53d1ade148e2">Fix default border color.</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="overtrue">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/overtrue/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/overtrue">
          <img height="20" width="20" alt="@overtrue" src="https://avatars1.githubusercontent.com/u/1472352?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/tailwindcss/tailwindcss/commits?author=overtrue"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by overtrue">overtrue</a>


  committed
  <relative-time datetime="2019-03-18T08:23:43Z" class="no-wrap">Mar 18, 2019</relative-time>

    </div>
      <div class="commit-indicator">
        
  <details class="commit-build-statuses details-overlay details-reset js-dropdown-details"
    data-deferred-details-content-url="/_render_node/MDE3OlN0YXR1c0NoZWNrUm9sbHVwMTA2MDE3MzQzOjliZjQxMzkzM2M3ZjExMThhNDdlNzhkMzY1ZTEzYjMyN2U0OGY1YTY=/statuses/combined_branch_status">
    <summary class="text-red">
      <svg aria-label="0 / 1 checks OK" class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" role="img"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
    </summary>
    <div class="dropdown-menu dropdown-menu-e overflow-hidden">
      <include-fragment class="m-4 d-flex flex-column flex-items-center">
        <div class="anim-pulse"><svg height="32" class="octicon octicon-octoface" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M14.7 5.34c.13-.32.55-1.59-.13-3.31 0 0-1.05-.33-3.44 1.3-1-.28-2.07-.32-3.13-.32s-2.13.04-3.13.32c-2.39-1.64-3.44-1.3-3.44-1.3-.68 1.72-.26 2.99-.13 3.31C.49 6.21 0 7.33 0 8.69 0 13.84 3.33 15 7.98 15S16 13.84 16 8.69c0-1.36-.49-2.48-1.3-3.35zM8 14.02c-3.3 0-5.98-.15-5.98-3.35 0-.76.38-1.48 1.02-2.07 1.07-.98 2.9-.46 4.96-.46 2.07 0 3.88-.52 4.96.46.65.59 1.02 1.3 1.02 2.07 0 3.19-2.68 3.35-5.98 3.35zM5.49 9.01c-.66 0-1.2.8-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.54-1.78-1.2-1.78zm5.02 0c-.66 0-1.2.79-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.53-1.78-1.2-1.78z"/></svg></div>
        <div class="text-gray no-wrap">Loading status checks&hellip;</div>
      </include-fragment>
    </div>
  </details>


      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  
    <details class="dropdown dropdown-signed-commit details-reset details-overlay js-dropdown-details d-inline-block ml-1">
        <summary class="signed-commit-badge signed-commit-badge-large verified"
          title="Commit signature">
            Verified
        </summary>
        <div class="anim-scale-in" style="position: relative; z-index: 200;">
          <div class="dropdown-menu dropdown-menu-s py-0 text-gray-dark text-left">
            <div class="signed-commit-header TableObject">
              <div class="TableObject-item">
                <svg height="32" class="octicon octicon-verified mr-2" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M15.67 7.066l-1.08-1.34a1.5 1.5 0 01-.309-.77l-.19-1.698a1.51 1.51 0 00-1.329-1.33l-1.699-.19c-.3-.03-.56-.159-.78-.329L8.945.33a1.504 1.504 0 00-1.878 0l-1.34 1.08a1.5 1.5 0 01-.77.31l-1.698.19c-.7.08-1.25.63-1.33 1.329l-.19 1.699c-.03.3-.159.56-.329.78L.33 7.055a1.504 1.504 0 000 1.878l1.08 1.34c.17.22.28.48.31.77l.19 1.698c.08.7.63 1.25 1.329 1.33l1.699.19c.3.03.56.159.78.329l1.339 1.08c.55.439 1.329.439 1.878 0l1.34-1.08c.22-.17.48-.28.77-.31l1.698-.19c.7-.08 1.25-.63 1.33-1.329l.19-1.699c.03-.3.159-.56.329-.78l1.08-1.339a1.504 1.504 0 000-1.878zM6.5 12.01L3 8.51l1.5-1.5 2 2 5-5L13 5.56l-6.5 6.45z"/></svg>
              </div>
              <div class="TableObject-item--primary">
                    This commit was created on GitHub.com and signed with a <strong class="signed-commit-verified-label">verified signature</strong> using GitHub’s key.
              </div>
            </div>


            <div class="signed-commit-footer">
                <span class="d-block">GPG key ID: <span class="text-gray">4AEE18F83AFDEB23</span></span>
              <a href="https://help.github.com/articles/signing-commits-with-gpg/">Learn about signing commits</a>
            </div>
          </div>
        </div>
    </details>


  <div class="commit-links-group BtnGroup">
    <clipboard-copy value="9bf413933c7f1118a47e78d365e13b327e48f5a6" aria-label="Copy the full SHA" class="btn btn-outline BtnGroup-item">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/tailwindcss/tailwindcss/commit/9bf413933c7f1118a47e78d365e13b327e48f5a6#diff-35dd1ebd14934754769c53d1ade148e2" class="sha btn btn-outline BtnGroup-item">
      9bf4139
    </a>
  </div>
  <a href="/tailwindcss/tailwindcss/tree/9bf413933c7f1118a47e78d365e13b327e48f5a6" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 17, 2019
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item js-commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:106017343:commit:cd15b2d76c4adc0da0fbb2204247e446a3f2d439"
    data-url="/tailwindcss/tailwindcss/commit/cd15b2d76c4adc0da0fbb2204247e446a3f2d439/_render_node/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a aria-label="Update defaultConfig.stub.js

missing comma" class="message js-navigation-open" data-pjax="true" href="/tailwindcss/tailwindcss/commit/cd15b2d76c4adc0da0fbb2204247e446a3f2d439#diff-35dd1ebd14934754769c53d1ade148e2">Update defaultConfig.stub.js</a>

      <span class="hidden-text-expander inline">
        <button type="button" class="ellipsis-expander js-details-target" aria-expanded="false">&hellip;</button>
      </span>
  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="kevinruscoe">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/kevinruscoe/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/kevinruscoe">
          <img height="20" width="20" alt="@kevinruscoe" src="https://avatars3.githubusercontent.com/u/547749?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/tailwindcss/tailwindcss/commits?author=kevinruscoe"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by kevinruscoe">kevinruscoe</a>


  committed
  <relative-time datetime="2019-03-17T23:07:15Z" class="no-wrap">Mar 17, 2019</relative-time>

    </div>
      <div class="commit-indicator">
        
  <details class="commit-build-statuses details-overlay details-reset js-dropdown-details"
    data-deferred-details-content-url="/_render_node/MDE3OlN0YXR1c0NoZWNrUm9sbHVwMTA2MDE3MzQzOmNkMTViMmQ3NmM0YWRjMGRhMGZiYjIyMDQyNDdlNDQ2YTNmMmQ0Mzk=/statuses/combined_branch_status">
    <summary class="text-green">
      <svg aria-label="1 / 1 checks OK" class="octicon octicon-check" viewBox="0 0 12 16" version="1.1" width="12" height="16" role="img"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
    </summary>
    <div class="dropdown-menu dropdown-menu-e overflow-hidden">
      <include-fragment class="m-4 d-flex flex-column flex-items-center">
        <div class="anim-pulse"><svg height="32" class="octicon octicon-octoface" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M14.7 5.34c.13-.32.55-1.59-.13-3.31 0 0-1.05-.33-3.44 1.3-1-.28-2.07-.32-3.13-.32s-2.13.04-3.13.32c-2.39-1.64-3.44-1.3-3.44-1.3-.68 1.72-.26 2.99-.13 3.31C.49 6.21 0 7.33 0 8.69 0 13.84 3.33 15 7.98 15S16 13.84 16 8.69c0-1.36-.49-2.48-1.3-3.35zM8 14.02c-3.3 0-5.98-.15-5.98-3.35 0-.76.38-1.48 1.02-2.07 1.07-.98 2.9-.46 4.96-.46 2.07 0 3.88-.52 4.96.46.65.59 1.02 1.3 1.02 2.07 0 3.19-2.68 3.35-5.98 3.35zM5.49 9.01c-.66 0-1.2.8-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.54-1.78-1.2-1.78zm5.02 0c-.66 0-1.2.79-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.53-1.78-1.2-1.78z"/></svg></div>
        <div class="text-gray no-wrap">Loading status checks&hellip;</div>
      </include-fragment>
    </div>
  </details>


      </div>
  </div>

    <div class="commit-desc"><pre class="text-small">missing comma</pre></div>

</div>

<div class="commit-links-cell table-list-cell">

  
    <details class="dropdown dropdown-signed-commit details-reset details-overlay js-dropdown-details d-inline-block ml-1">
        <summary class="signed-commit-badge signed-commit-badge-large verified"
          title="Commit signature">
            Verified
        </summary>
        <div class="anim-scale-in" style="position: relative; z-index: 200;">
          <div class="dropdown-menu dropdown-menu-s py-0 text-gray-dark text-left">
            <div class="signed-commit-header TableObject">
              <div class="TableObject-item">
                <svg height="32" class="octicon octicon-verified mr-2" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M15.67 7.066l-1.08-1.34a1.5 1.5 0 01-.309-.77l-.19-1.698a1.51 1.51 0 00-1.329-1.33l-1.699-.19c-.3-.03-.56-.159-.78-.329L8.945.33a1.504 1.504 0 00-1.878 0l-1.34 1.08a1.5 1.5 0 01-.77.31l-1.698.19c-.7.08-1.25.63-1.33 1.329l-.19 1.699c-.03.3-.159.56-.329.78L.33 7.055a1.504 1.504 0 000 1.878l1.08 1.34c.17.22.28.48.31.77l.19 1.698c.08.7.63 1.25 1.329 1.33l1.699.19c.3.03.56.159.78.329l1.339 1.08c.55.439 1.329.439 1.878 0l1.34-1.08c.22-.17.48-.28.77-.31l1.698-.19c.7-.08 1.25-.63 1.33-1.329l.19-1.699c.03-.3.159-.56.329-.78l1.08-1.339a1.504 1.504 0 000-1.878zM6.5 12.01L3 8.51l1.5-1.5 2 2 5-5L13 5.56l-6.5 6.45z"/></svg>
              </div>
              <div class="TableObject-item--primary">
                    This commit was created on GitHub.com and signed with a <strong class="signed-commit-verified-label">verified signature</strong> using GitHub’s key.
              </div>
            </div>


            <div class="signed-commit-footer">
                <span class="d-block">GPG key ID: <span class="text-gray">4AEE18F83AFDEB23</span></span>
              <a href="https://help.github.com/articles/signing-commits-with-gpg/">Learn about signing commits</a>
            </div>
          </div>
        </div>
    </details>


  <div class="commit-links-group BtnGroup">
    <clipboard-copy value="cd15b2d76c4adc0da0fbb2204247e446a3f2d439" aria-label="Copy the full SHA" class="btn btn-outline BtnGroup-item">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/tailwindcss/tailwindcss/commit/cd15b2d76c4adc0da0fbb2204247e446a3f2d439#diff-35dd1ebd14934754769c53d1ade148e2" class="sha btn btn-outline BtnGroup-item">
      cd15b2d
    </a>
  </div>
  <a href="/tailwindcss/tailwindcss/tree/cd15b2d76c4adc0da0fbb2204247e446a3f2d439" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

            <li class="commit commits-list-item js-commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:106017343:commit:46d0f7aff3866b9cc9017cbb926c0d73d774106d"
    data-url="/tailwindcss/tailwindcss/commit/46d0f7aff3866b9cc9017cbb926c0d73d774106d/_render_node/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a aria-label="Update defaultConfig.stub.js

The serif array seems to be on a single line whereas every other array is multiline, this just adds consistency." class="message js-navigation-open" data-pjax="true" href="/tailwindcss/tailwindcss/commit/46d0f7aff3866b9cc9017cbb926c0d73d774106d#diff-35dd1ebd14934754769c53d1ade148e2">Update defaultConfig.stub.js</a>

      <span class="hidden-text-expander inline">
        <button type="button" class="ellipsis-expander js-details-target" aria-expanded="false">&hellip;</button>
      </span>
  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="kevinruscoe">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/kevinruscoe/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/kevinruscoe">
          <img height="20" width="20" alt="@kevinruscoe" src="https://avatars3.githubusercontent.com/u/547749?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/tailwindcss/tailwindcss/commits?author=kevinruscoe"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by kevinruscoe">kevinruscoe</a>


  committed
  <relative-time datetime="2019-03-17T14:13:34Z" class="no-wrap">Mar 17, 2019</relative-time>

    </div>
      <div class="commit-indicator">
        
  <details class="commit-build-statuses details-overlay details-reset js-dropdown-details"
    data-deferred-details-content-url="/_render_node/MDE3OlN0YXR1c0NoZWNrUm9sbHVwMTA2MDE3MzQzOjQ2ZDBmN2FmZjM4NjZiOWNjOTAxN2NiYjkyNmMwZDczZDc3NDEwNmQ=/statuses/combined_branch_status">
    <summary class="text-green">
      <svg aria-label="1 / 1 checks OK" class="octicon octicon-check" viewBox="0 0 12 16" version="1.1" width="12" height="16" role="img"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
    </summary>
    <div class="dropdown-menu dropdown-menu-e overflow-hidden">
      <include-fragment class="m-4 d-flex flex-column flex-items-center">
        <div class="anim-pulse"><svg height="32" class="octicon octicon-octoface" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M14.7 5.34c.13-.32.55-1.59-.13-3.31 0 0-1.05-.33-3.44 1.3-1-.28-2.07-.32-3.13-.32s-2.13.04-3.13.32c-2.39-1.64-3.44-1.3-3.44-1.3-.68 1.72-.26 2.99-.13 3.31C.49 6.21 0 7.33 0 8.69 0 13.84 3.33 15 7.98 15S16 13.84 16 8.69c0-1.36-.49-2.48-1.3-3.35zM8 14.02c-3.3 0-5.98-.15-5.98-3.35 0-.76.38-1.48 1.02-2.07 1.07-.98 2.9-.46 4.96-.46 2.07 0 3.88-.52 4.96.46.65.59 1.02 1.3 1.02 2.07 0 3.19-2.68 3.35-5.98 3.35zM5.49 9.01c-.66 0-1.2.8-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.54-1.78-1.2-1.78zm5.02 0c-.66 0-1.2.79-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.53-1.78-1.2-1.78z"/></svg></div>
        <div class="text-gray no-wrap">Loading status checks&hellip;</div>
      </include-fragment>
    </div>
  </details>


      </div>
  </div>

    <div class="commit-desc"><pre class="text-small">The serif array seems to be on a single line whereas every other array is multiline, this just adds consistency.</pre></div>

</div>

<div class="commit-links-cell table-list-cell">

  
    <details class="dropdown dropdown-signed-commit details-reset details-overlay js-dropdown-details d-inline-block ml-1">
        <summary class="signed-commit-badge signed-commit-badge-large verified"
          title="Commit signature">
            Verified
        </summary>
        <div class="anim-scale-in" style="position: relative; z-index: 200;">
          <div class="dropdown-menu dropdown-menu-s py-0 text-gray-dark text-left">
            <div class="signed-commit-header TableObject">
              <div class="TableObject-item">
                <svg height="32" class="octicon octicon-verified mr-2" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M15.67 7.066l-1.08-1.34a1.5 1.5 0 01-.309-.77l-.19-1.698a1.51 1.51 0 00-1.329-1.33l-1.699-.19c-.3-.03-.56-.159-.78-.329L8.945.33a1.504 1.504 0 00-1.878 0l-1.34 1.08a1.5 1.5 0 01-.77.31l-1.698.19c-.7.08-1.25.63-1.33 1.329l-.19 1.699c-.03.3-.159.56-.329.78L.33 7.055a1.504 1.504 0 000 1.878l1.08 1.34c.17.22.28.48.31.77l.19 1.698c.08.7.63 1.25 1.329 1.33l1.699.19c.3.03.56.159.78.329l1.339 1.08c.55.439 1.329.439 1.878 0l1.34-1.08c.22-.17.48-.28.77-.31l1.698-.19c.7-.08 1.25-.63 1.33-1.329l.19-1.699c.03-.3.159-.56.329-.78l1.08-1.339a1.504 1.504 0 000-1.878zM6.5 12.01L3 8.51l1.5-1.5 2 2 5-5L13 5.56l-6.5 6.45z"/></svg>
              </div>
              <div class="TableObject-item--primary">
                    This commit was created on GitHub.com and signed with a <strong class="signed-commit-verified-label">verified signature</strong> using GitHub’s key.
              </div>
            </div>


            <div class="signed-commit-footer">
                <span class="d-block">GPG key ID: <span class="text-gray">4AEE18F83AFDEB23</span></span>
              <a href="https://help.github.com/articles/signing-commits-with-gpg/">Learn about signing commits</a>
            </div>
          </div>
        </div>
    </details>


  <div class="commit-links-group BtnGroup">
    <clipboard-copy value="46d0f7aff3866b9cc9017cbb926c0d73d774106d" aria-label="Copy the full SHA" class="btn btn-outline BtnGroup-item">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/tailwindcss/tailwindcss/commit/46d0f7aff3866b9cc9017cbb926c0d73d774106d#diff-35dd1ebd14934754769c53d1ade148e2" class="sha btn btn-outline BtnGroup-item">
      46d0f7a
    </a>
  </div>
  <a href="/tailwindcss/tailwindcss/tree/46d0f7aff3866b9cc9017cbb926c0d73d774106d" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 16, 2019
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item js-commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:106017343:commit:da10af26ebcd3f4013e6fd97dd031edb2c60bd02"
    data-url="/tailwindcss/tailwindcss/commit/da10af26ebcd3f4013e6fd97dd031edb2c60bd02/_render_node/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a aria-label="Update defaultConfig to use theme function" class="message js-navigation-open" data-pjax="true" href="/tailwindcss/tailwindcss/commit/da10af26ebcd3f4013e6fd97dd031edb2c60bd02#diff-35dd1ebd14934754769c53d1ade148e2">Update defaultConfig to use theme function</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/tailwindcss/tailwindcss/commits?author=adamwathan"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by adamwathan">adamwathan</a>


  committed
  <relative-time datetime="2019-03-16T20:28:39Z" class="no-wrap">Mar 16, 2019</relative-time>

    </div>
      <div class="commit-indicator">
        
  <details class="commit-build-statuses details-overlay details-reset js-dropdown-details"
    data-deferred-details-content-url="/_render_node/MDE3OlN0YXR1c0NoZWNrUm9sbHVwMTA2MDE3MzQzOmRhMTBhZjI2ZWJjZDNmNDAxM2U2ZmQ5N2RkMDMxZWRiMmM2MGJkMDI=/statuses/combined_branch_status">
    <summary class="text-green">
      <svg aria-label="1 / 1 checks OK" class="octicon octicon-check" viewBox="0 0 12 16" version="1.1" width="12" height="16" role="img"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
    </summary>
    <div class="dropdown-menu dropdown-menu-e overflow-hidden">
      <include-fragment class="m-4 d-flex flex-column flex-items-center">
        <div class="anim-pulse"><svg height="32" class="octicon octicon-octoface" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M14.7 5.34c.13-.32.55-1.59-.13-3.31 0 0-1.05-.33-3.44 1.3-1-.28-2.07-.32-3.13-.32s-2.13.04-3.13.32c-2.39-1.64-3.44-1.3-3.44-1.3-.68 1.72-.26 2.99-.13 3.31C.49 6.21 0 7.33 0 8.69 0 13.84 3.33 15 7.98 15S16 13.84 16 8.69c0-1.36-.49-2.48-1.3-3.35zM8 14.02c-3.3 0-5.98-.15-5.98-3.35 0-.76.38-1.48 1.02-2.07 1.07-.98 2.9-.46 4.96-.46 2.07 0 3.88-.52 4.96.46.65.59 1.02 1.3 1.02 2.07 0 3.19-2.68 3.35-5.98 3.35zM5.49 9.01c-.66 0-1.2.8-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.54-1.78-1.2-1.78zm5.02 0c-.66 0-1.2.79-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.53-1.78-1.2-1.78z"/></svg></div>
        <div class="text-gray no-wrap">Loading status checks&hellip;</div>
      </include-fragment>
    </div>
  </details>


      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy value="da10af26ebcd3f4013e6fd97dd031edb2c60bd02" aria-label="Copy the full SHA" class="btn btn-outline BtnGroup-item">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/tailwindcss/tailwindcss/commit/da10af26ebcd3f4013e6fd97dd031edb2c60bd02#diff-35dd1ebd14934754769c53d1ade148e2" class="sha btn btn-outline BtnGroup-item">
      da10af2
    </a>
  </div>
  <a href="/tailwindcss/tailwindcss/tree/da10af26ebcd3f4013e6fd97dd031edb2c60bd02" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 15, 2019
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item js-commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:106017343:commit:426a549e500c7f5a611576a9bd10e24aef64e347"
    data-url="/tailwindcss/tailwindcss/commit/426a549e500c7f5a611576a9bd10e24aef64e347/_render_node/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a aria-label="Update shadow-outline to be based on new blue" class="message js-navigation-open" data-pjax="true" href="/tailwindcss/tailwindcss/commit/426a549e500c7f5a611576a9bd10e24aef64e347#diff-35dd1ebd14934754769c53d1ade148e2">Update shadow-outline to be based on new blue</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="adamwathan">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/adamwathan/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adamwathan">
          <img height="20" width="20" alt="@adamwathan" src="https://avatars0.githubusercontent.com/u/4323180?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/tailwindcss/tailwindcss/commits?author=adamwathan"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by adamwathan">adamwathan</a>


  committed
  <relative-time datetime="2019-03-15T15:13:46Z" class="no-wrap">Mar 15, 2019</relative-time>

    </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy value="426a549e500c7f5a611576a9bd10e24aef64e347" aria-label="Copy the full SHA" class="btn btn-outline BtnGroup-item">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/tailwindcss/tailwindcss/commit/426a549e500c7f5a611576a9bd10e24aef64e347#diff-35dd1ebd14934754769c53d1ade148e2" class="sha btn btn-outline BtnGroup-item">
      426a549
    </a>
  </div>
  <a href="/tailwindcss/tailwindcss/tree/426a549e500c7f5a611576a9bd10e24aef64e347" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

            <li class="commit commits-list-item js-commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:106017343:commit:71b11a667ac341b696b37f08522f91ca8a2884a0"
    data-url="/tailwindcss/tailwindcss/commit/71b11a667ac341b696b37f08522f91ca8a2884a0/_render_node/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a aria-label="Updating the stub" class="message js-navigation-open" data-pjax="true" href="/tailwindcss/tailwindcss/commit/71b11a667ac341b696b37f08522f91ca8a2884a0#diff-35dd1ebd14934754769c53d1ade148e2">Updating the stub</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/tailwindcss/tailwindcss/commits?author=MattStypa"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by MattStypa">MattStypa</a>


  committed
  <relative-time datetime="2019-03-15T14:05:06Z" class="no-wrap">Mar 15, 2019</relative-time>

    </div>
      <div class="commit-indicator">
        
  <details class="commit-build-statuses details-overlay details-reset js-dropdown-details"
    data-deferred-details-content-url="/_render_node/MDE3OlN0YXR1c0NoZWNrUm9sbHVwMTA2MDE3MzQzOjcxYjExYTY2N2FjMzQxYjY5NmIzN2YwODUyMmY5MWNhOGEyODg0YTA=/statuses/combined_branch_status">
    <summary class="text-green">
      <svg aria-label="1 / 1 checks OK" class="octicon octicon-check" viewBox="0 0 12 16" version="1.1" width="12" height="16" role="img"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
    </summary>
    <div class="dropdown-menu dropdown-menu-e overflow-hidden">
      <include-fragment class="m-4 d-flex flex-column flex-items-center">
        <div class="anim-pulse"><svg height="32" class="octicon octicon-octoface" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M14.7 5.34c.13-.32.55-1.59-.13-3.31 0 0-1.05-.33-3.44 1.3-1-.28-2.07-.32-3.13-.32s-2.13.04-3.13.32c-2.39-1.64-3.44-1.3-3.44-1.3-.68 1.72-.26 2.99-.13 3.31C.49 6.21 0 7.33 0 8.69 0 13.84 3.33 15 7.98 15S16 13.84 16 8.69c0-1.36-.49-2.48-1.3-3.35zM8 14.02c-3.3 0-5.98-.15-5.98-3.35 0-.76.38-1.48 1.02-2.07 1.07-.98 2.9-.46 4.96-.46 2.07 0 3.88-.52 4.96.46.65.59 1.02 1.3 1.02 2.07 0 3.19-2.68 3.35-5.98 3.35zM5.49 9.01c-.66 0-1.2.8-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.54-1.78-1.2-1.78zm5.02 0c-.66 0-1.2.79-1.2 1.78s.54 1.79 1.2 1.79c.66 0 1.2-.8 1.2-1.79s-.53-1.78-1.2-1.78z"/></svg></div>
        <div class="text-gray no-wrap">Loading status checks&hellip;</div>
      </include-fragment>
    </div>
  </details>


      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy value="71b11a667ac341b696b37f08522f91ca8a2884a0" aria-label="Copy the full SHA" class="btn btn-outline BtnGroup-item">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/tailwindcss/tailwindcss/commit/71b11a667ac341b696b37f08522f91ca8a2884a0#diff-35dd1ebd14934754769c53d1ade148e2" class="sha btn btn-outline BtnGroup-item">
      71b11a6
    </a>
  </div>
  <a href="/tailwindcss/tailwindcss/tree/71b11a667ac341b696b37f08522f91ca8a2884a0" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 14, 2019
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item js-commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:106017343:commit:e0cad52c571f761aa6f5faaad03a80eae1108c84"
    data-url="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84/_render_node/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a aria-label="Added a file that was removed during merge" class="message js-navigation-open" data-pjax="true" href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84#diff-35dd1ebd14934754769c53d1ade148e2">Added a file that was removed during merge</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/tailwindcss/tailwindcss/commits?author=MattStypa"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by MattStypa">MattStypa</a>


  committed
  <relative-time datetime="2019-03-14T23:09:42Z" class="no-wrap">Mar 14, 2019</relative-time>

    </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy value="e0cad52c571f761aa6f5faaad03a80eae1108c84" aria-label="Copy the full SHA" class="btn btn-outline BtnGroup-item">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/tailwindcss/tailwindcss/commit/e0cad52c571f761aa6f5faaad03a80eae1108c84#diff-35dd1ebd14934754769c53d1ade148e2" class="sha btn btn-outline BtnGroup-item">
      e0cad52
    </a>
  </div>
  <a href="/tailwindcss/tailwindcss/tree/e0cad52c571f761aa6f5faaad03a80eae1108c84" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

            <li class="commit commits-list-item js-commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:106017343:commit:92b3b0c0a1ef79c1ec7636e04674a5dfab687199"
    data-url="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199/_render_node/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a aria-label="Updated CLI init commend" class="message js-navigation-open" data-pjax="true" href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199#diff-35dd1ebd14934754769c53d1ade148e2">Updated CLI init commend</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="MattStypa">
        <a class="avatar" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/users/MattStypa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/MattStypa">
          <img height="20" width="20" alt="@MattStypa" src="https://avatars2.githubusercontent.com/u/5871133?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/tailwindcss/tailwindcss/commits?author=MattStypa"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by MattStypa">MattStypa</a>


  committed
  <relative-time datetime="2019-03-14T20:51:21Z" class="no-wrap">Mar 14, 2019</relative-time>

    </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy value="92b3b0c0a1ef79c1ec7636e04674a5dfab687199" aria-label="Copy the full SHA" class="btn btn-outline BtnGroup-item">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/tailwindcss/tailwindcss/commit/92b3b0c0a1ef79c1ec7636e04674a5dfab687199#diff-35dd1ebd14934754769c53d1ade148e2" class="sha btn btn-outline BtnGroup-item">
      92b3b0c
    </a>
  </div>
  <a href="/tailwindcss/tailwindcss/tree/92b3b0c0a1ef79c1ec7636e04674a5dfab687199" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
    </div>

    <div class="paginate-container" data-pjax data-html-cleaner-suppress-children>
      <div class="BtnGroup" data-test-selector="pagination"><a rel="nofollow" class="btn btn-outline BtnGroup-item" href="https://github.com/tailwindcss/tailwindcss/commits/master?before=254252ac8eb2ce0fba69409664c5eb212d6b07e6+70&amp;path%5B%5D=stubs&amp;path%5B%5D=defaultConfig.stub.js">Newer</a><button class="btn btn-outline BtnGroup-item" disabled="disabled">Older</button></div>
    </div>




  </div>
</div>

    </main>
  </div>
  

  </div>

        
<div class="footer container-lg width-full px-3" role="contentinfo">
  <div class="position-relative d-flex flex-justify-between pt-6 pb-2 mt-6 f6 text-gray border-top border-gray-light ">
    <ul class="list-style-none d-flex flex-wrap ">
      <li class="mr-3">&copy; 2020 GitHub, Inc.</li>
        <li class="mr-3"><a data-ga-click="Footer, go to terms, text:terms" href="https://github.com/site/terms">Terms</a></li>
        <li class="mr-3"><a data-ga-click="Footer, go to privacy, text:privacy" href="https://github.com/site/privacy">Privacy</a></li>
        <li class="mr-3"><a data-ga-click="Footer, go to security, text:security" href="https://github.com/security">Security</a></li>
        <li class="mr-3"><a href="https://githubstatus.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
        <li><a data-ga-click="Footer, go to help, text:help" href="https://help.github.com">Help</a></li>
    </ul>

    <a aria-label="Homepage" title="GitHub" class="footer-octicon d-none d-lg-block mx-lg-4" href="https://github.com">
      <svg height="24" class="octicon octicon-mark-github" viewBox="0 0 16 16" version="1.1" width="24" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg>
</a>
   <ul class="list-style-none d-flex flex-wrap ">
        <li class="mr-3"><a data-ga-click="Footer, go to contact, text:contact" href="https://github.com/contact">Contact GitHub</a></li>
        <li class="mr-3"><a href="https://github.com/pricing" data-ga-click="Footer, go to Pricing, text:Pricing">Pricing</a></li>
      <li class="mr-3"><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li class="mr-3"><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
        <li class="mr-3"><a href="https://github.blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a data-ga-click="Footer, go to about, text:about" href="https://github.com/about">About</a></li>

    </ul>
  </div>
  <div class="d-flex flex-justify-center pb-6">
    <span class="f6 text-gray-light"></span>
  </div>
</div>



  <div id="ajax-error-message" class="ajax-error-message flash flash-error">
    <svg class="octicon octicon-alert" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.893 1.5c-.183-.31-.52-.5-.887-.5s-.703.19-.886.5L.138 13.499a.98.98 0 000 1.001c.193.31.53.501.886.501h13.964c.367 0 .704-.19.877-.5a1.03 1.03 0 00.01-1.002L8.893 1.5zm.133 11.497H6.987v-2.003h2.039v2.003zm0-3.004H6.987V5.987h2.039v4.006z"/></svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
    </button>
    You can’t perform that action at this time.
  </div>


    <script crossorigin="anonymous" async="async" integrity="sha512-VTkKwyyXYz1e8w0v/7LXDKSa7yMy1qEQofgf/5bGrUv8wpbpaZxx5S3Uc6oYrvbOe432HJdJG5qsFdM9sbP+wg==" type="application/javascript" id="js-conditional-compat" data-src="https://github.githubassets.com/assets/compat-bootstrap-55390ac3.js"></script>
    <script crossorigin="anonymous" integrity="sha512-cxP+KR1XSSh29AL463dzUAHBchhXeGFmau39mDoF/w4eoAdNHqqynVYGNL8bMC65SDQYbQeDpk71eMKadQhObQ==" type="application/javascript" src="https://github.githubassets.com/assets/frameworks-7313fe29.js"></script>
    
    <script crossorigin="anonymous" async="async" integrity="sha512-pQP8Cv0kHJnTpys259V7ucuuxw2JdOaW2+7bUevII7Fv/iH8Pg7e+VEQtsf2BPCPq6cgJ955C1iQ7C+ziBcFyQ==" type="application/javascript" src="https://github.githubassets.com/assets/github-bootstrap-a503fc0a.js"></script>
    
    
    
  <div class="js-stale-session-flash flash flash-warn flash-banner" hidden
    >
    <svg class="octicon octicon-alert" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.893 1.5c-.183-.31-.52-.5-.887-.5s-.703.19-.886.5L.138 13.499a.98.98 0 000 1.001c.193.31.53.501.886.501h13.964c.367 0 .704-.19.877-.5a1.03 1.03 0 00.01-1.002L8.893 1.5zm.133 11.497H6.987v-2.003h2.039v2.003zm0-3.004H6.987V5.987h2.039v4.006z"/></svg>
    <span class="js-stale-session-flash-signed-in" hidden>You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="js-stale-session-flash-signed-out" hidden>You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
  <template id="site-details-dialog">
  <details class="details-reset details-overlay details-overlay-dark lh-default text-gray-dark hx_rsm" open>
    <summary role="button" aria-label="Close dialog"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast hx_rsm-dialog hx_rsm-modal">
      <button class="Box-btn-octicon m-0 btn-octicon position-absolute right-0 top-0" type="button" aria-label="Close dialog" data-close-dialog>
        <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
      </button>
      <div class="octocat-spinner my-6 js-details-dialog-spinner"></div>
    </details-dialog>
  </details>
</template>

  <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box box-shadow-large" style="width:360px;">
  </div>
</div>

  <div aria-live="polite" class="js-global-screen-reader-notice sr-only"></div>

  </body>
</html>

